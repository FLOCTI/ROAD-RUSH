extends Node2D

const VIEW_SIZE := Vector2(960, 540)
const WORDMARK_SIZE := Vector2(765, 105)
const WORDMARK_HOME_Y := 88.0
const INTRO_RUNNER_START := 0.0
const INTRO_OFFICER_START := 1.0
const INTRO_LOGO_START := 2.0
const INTRO_LOGO_SLIDE_DURATION := 0.8
const INTRO_LOGO_IMPACT_DURATION := 0.32
const INTRO_DURATION := 3.5
const INTRO_FADE_OUT_DURATION := INTRO_DURATION - INTRO_LOGO_START - INTRO_LOGO_SLIDE_DURATION - INTRO_LOGO_IMPACT_DURATION
const INTRO_FADE_OUT_START := INTRO_DURATION - INTRO_FADE_OUT_DURATION
const INTRO_ROAD_TOP := 446.0
const INTRO_GROUND_Y := 496.0
const INTRO_CHARACTER_SIZE := Vector2(144, 144)
const INTRO_OFFICER_SCALE := 1.5
const INTRO_JEEPNEY_SIZE := Vector2(340, 190)
const INTRO_JEEPNEY_CHASE_GAP := 14.0
const PLAYER_SIZE := Vector2(34, 62)
const RUNNER_OFFICER_SCALE := 0.84
const RUNNER_COIN_VALUE := 2
const RUNNER_COIN_SPAWN_INTERVAL := 0.72
const RUNNER_TRAFFIC_SPEED_MULTIPLIER := 2.0
const CROSSWALK_LEFT := 414.0
const CROSSWALK_RIGHT := 538.0
const CROSSWALK_PAINT_BLOCK_SIZE := 12.0
const CROSSWALK_PAINT_STRIPES := [
	Vector2(18, 84), Vector2(2, 120), Vector2(38, 72), Vector2(5, 108),
	Vector2(17, 96), Vector2(1, 120), Vector2(41, 72), Vector2(8, 108),
]
const CROSSING_ROAD_TOP := 111.0
const CROSSING_ROAD_BOTTOM := 425.0
const CROSSING_WARNING_RECT := Rect2(8, 416, 204, 48)
const CROSSING_SIGNAL_RECT := Rect2(224, 416, 172, 48)
const CROSSING_HIT_RECT := Rect2(324, 96, 312, 43)
const SIGNAL_GREEN_DURATION := 7.0
const SIGNAL_YELLOW_DURATION := 1.0
const SIGNAL_RED_DURATION := 5.0
const SIGNAL_CYCLE_DURATION := SIGNAL_GREEN_DURATION + SIGNAL_YELLOW_DURATION + SIGNAL_RED_DURATION
const CROSSING_COIN_VALUE := 5
const RUNNER_ROAD_LEFT := 190.0
const RUNNER_ROAD_RIGHT := 770.0
const RUNNER_PLAYER_Y := 390.0
const RUNNER_PLAYER_MIN_Y := 330.0
const RUNNER_PLAYER_MAX_Y := 410.0
const RUNNER_LANES := [255.0, 370.0, 485.0, 600.0, 715.0]
const RUN_DURATION := 120.0
const WASD_GUIDE_SIZE := Vector2(122, 81)
const WASD_KEY_SIZE := Vector2(36, 36)
const WASD_ACTIONS := {
	"W": "move_up",
	"A": "move_left",
	"S": "move_down",
	"D": "move_right",
}
const CAR_COLORS := [
	Color("#e85d4b"),
	Color("#efbd43"),
	Color("#43a39a"),
	Color("#8b76b9"),
	Color("#d9e1cf"),
	Color("#d77f69"),
]
const SAVE_PATH := "user://road_rush_save.cfg"
const ARRIVAL_CELEBRATION_DURATION := 4.0
const JAYWALK_CATCH_DURATION := 3.0
const AUDIO_SAMPLE_RATE := 11025
const STARTING_ALLOWANCE := 150
const STARTING_ATTEMPTS := 3
const GIRL_TEXTURE := preload("res://assets/student_girl.png")
const BOY_TEXTURE := preload("res://assets/student_boy.png")
const UI_STYLE_SCRIPT := preload("res://scripts/road_rush_ui_style.gd")
var rng := RandomNumberGenerator.new()
var save_data := ConfigFile.new()
var ui_style: RefCounted
var profiles: Array[Dictionary] = []
var active_profile_id := ""
var selected_character := "girl"
var difficulty := "normal"
var music_enabled := true
var sfx_enabled := true
var best_score := 0
var has_survived := false
var fastest_arrival_time := 0.0
var fastest_arrival_name := ""
var highest_allowance := STARTING_ALLOWANCE
var highest_allowance_name := ""
var mini_game_longest_run := 0
var mini_game_highest_money_collected := 0
var mini_game_mode := false
var mini_game_money_collected := 0
var runner_timed_out := false

var mode := "home"
var overlay := ""
var intro_active := true
var intro_elapsed := 0.0
var celebration_elapsed := 0.0
var jaywalk_catch_elapsed := 0.0
var run_elapsed := 0.0
var home_reveal := 1.0
var player_name := "STUDENT"
var player_x := 468.0
var player_y := 470.0
var wallet := 150
var attempts_remaining := STARTING_ATTEMPTS
var officer_x := 0.0
var time_left := RUN_DURATION
var distance := 0.0
var stage := 1
var road_offset := 0.0
var spawn_timer := 1.0
var fee_popup_timer := 0.0
var runner_elapsed := 0.0
var runner_coin_spawn_timer := 0.0
var crossing_hit_timer := 0.0
var world_time := 0.0
var signal_elapsed := 0.0
var crossing_jaywalking := false
var crossing_coins_collected := 0
var crossing_cars: Array[Dictionary] = []
var crossing_coins: Array[Dictionary] = []
var hazards: Array[Dictionary] = []
var runner_coins: Array[Dictionary] = []
var ui_root: Control
var screen_root: Control
var hud_labels: Dictionary = {}
var virtual_move_actions: Dictionary = {}
var building_popup := false
var music_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var music_context := ""
var music_cache: Dictionary = {}
var sfx_cache: Dictionary = {}


func _ready() -> void:
	rng.randomize()
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ui_style = UI_STYLE_SCRIPT.new()
	ui_root = get_node("UI/Root") as Control
	var project_theme := ThemeDB.get_project_theme()
	if project_theme != null and project_theme.default_font is FontVariation:
		var arcade_font := project_theme.default_font as FontVariation
		if arcade_font.fallbacks.is_empty():
			arcade_font.fallbacks = [ThemeDB.fallback_font]
	_load_save()
	_configure_input()
	_setup_audio()
	_refresh_ui()
	screen_root.visible = not intro_active



func _setup_audio() -> void:
	music_player = AudioStreamPlayer.new()
	music_player.name = "MusicPlayer"
	music_player.volume_db = -20.0
	add_child(music_player)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.name = "SfxPlayer"
	sfx_player.volume_db = -8.0
	sfx_player.max_polyphony = 4
	add_child(sfx_player)
	_sync_audio_context()


func _sync_audio_context() -> void:
	if music_player == null:
		return
	if not music_enabled:
		if music_player.playing:
			music_player.stop()
		music_context = ""
		return
	var next_context := _audio_context()
	music_player.volume_db = -27.0 if overlay == "pause" else -20.0
	if next_context == music_context:
		return
	music_context = next_context
	if not music_cache.has(next_context):
		music_cache[next_context] = _make_music(next_context)
	music_player.stream = music_cache[next_context]
	music_player.play()


func _audio_context() -> String:
	if intro_active:
		return "intro"
	if overlay == "gameover":
		return "gameover"
	match mode:
		"crossing":
			return "crossing"
		"chase", "jaywalk_catch":
			return "chase"
		"celebration":
			return "victory"
		_:
			return "home"


func _make_music(context: String) -> AudioStreamWAV:
	var bpm := 112.0
	var notes := PackedFloat32Array([261.63, 329.63, 392.0, 329.63, 293.66, 349.23, 440.0, 349.23])
	match context:
		"intro":
			bpm = 144.0
			notes = PackedFloat32Array([164.81, 196.0, 246.94, 293.66, 329.63, 392.0, 493.88, 587.33])
		"crossing":
			bpm = 96.0
			notes = PackedFloat32Array([220.0, 261.63, 329.63, 261.63, 196.0, 246.94, 293.66, 246.94])
		"chase":
			bpm = 168.0
			notes = PackedFloat32Array([146.83, 174.61, 220.0, 293.66, 220.0, 349.23, 293.66, 233.08])
		"victory":
			bpm = 126.0
			notes = PackedFloat32Array([261.63, 329.63, 392.0, 523.25, 392.0, 440.0, 523.25, 659.25])
		"gameover":
			bpm = 72.0
			notes = PackedFloat32Array([220.0, 196.0, 174.61, 146.83, 164.81, 146.83, 130.81, 110.0])
	var duration := 8.0
	var sample_count := int(AUDIO_SAMPLE_RATE * duration)
	var data := PackedByteArray()
	data.resize(sample_count * 2)
	var steps_per_second := bpm / 30.0
	for index in range(sample_count):
		var time := float(index) / AUDIO_SAMPLE_RATE
		var step_position := time * steps_per_second
		var step := int(step_position) % notes.size()
		var step_phase := fposmod(step_position, 1.0)
		var frequency := notes[step]
		var melody := 1.0 if sin(TAU * frequency * time) >= 0.0 else -1.0
		var bass := 1.0 if sin(TAU * frequency * 0.25 * time) >= 0.0 else -1.0
		var envelope := minf(1.0, step_phase * 18.0) * maxf(0.0, 1.0 - step_phase * 0.72)
		var beat_phase := fposmod(time * bpm / 60.0, 1.0)
		var kick := sin(TAU * (70.0 - beat_phase * 38.0) * time) * exp(-beat_phase * 12.0)
		var value := melody * envelope * 0.11 + bass * 0.055 + kick * 0.045
		data.encode_s16(index * 2, int(clampf(value, -0.92, 0.92) * 32767.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = AUDIO_SAMPLE_RATE
	stream.stereo = false
	stream.data = data
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = sample_count
	return stream


func _play_sfx(cue: String) -> void:
	if sfx_player == null or not sfx_enabled:
		return
	if not sfx_cache.has(cue):
		sfx_cache[cue] = _make_sfx(cue)
	sfx_player.stream = sfx_cache[cue]
	sfx_player.play()


func _make_sfx(cue: String) -> AudioStreamWAV:
	var duration := 0.12
	match cue:
		"coin": duration = 0.24
		"crash": duration = 0.34
		"alert": duration = 0.46
		"start": duration = 0.42
		"win": duration = 0.72
		"gameover": duration = 0.62
	var sample_count := int(AUDIO_SAMPLE_RATE * duration)
	var data := PackedByteArray()
	data.resize(sample_count * 2)
	for index in range(sample_count):
		var time := float(index) / AUDIO_SAMPLE_RATE
		var progress := time / duration
		var value := 0.0
		match cue:
			"coin":
				var coin_frequency := 720.0 + 720.0 * progress
				value = sin(TAU * coin_frequency * time) * (1.0 - progress) * 0.42
			"crash":
				var noise := sin(index * 1.73) + sin(index * 0.37) + sin(index * 2.91)
				value = noise * exp(-progress * 5.0) * 0.18 + sin(TAU * 74.0 * time) * (1.0 - progress) * 0.28
			"alert":
				var alert_frequency := 620.0 if fposmod(time, 0.16) < 0.08 else 420.0
				value = (1.0 if sin(TAU * alert_frequency * time) >= 0.0 else -1.0) * (1.0 - progress) * 0.28
			"start":
				var start_step := mini(3, int(progress * 4.0))
				var start_frequency: float = [261.63, 329.63, 392.0, 523.25][start_step]
				value = sin(TAU * start_frequency * time) * (1.0 - fposmod(progress * 4.0, 1.0) * 0.55) * 0.34
			"win":
				var win_step := mini(5, int(progress * 6.0))
				var win_frequency: float = [261.63, 329.63, 392.0, 523.25, 659.25, 783.99][win_step]
				value = sin(TAU * win_frequency * time) * (1.0 - progress * 0.3) * 0.36
			"gameover":
				var fall_frequency := 330.0 - 220.0 * progress
				value = (1.0 if sin(TAU * fall_frequency * time) >= 0.0 else -1.0) * (1.0 - progress) * 0.28
			_:
				value = sin(TAU * 520.0 * time) * exp(-progress * 7.0) * 0.25
		data.encode_s16(index * 2, int(clampf(value, -0.92, 0.92) * 32767.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = AUDIO_SAMPLE_RATE
	stream.stereo = false
	stream.data = data
	return stream


func _configure_input() -> void:
	_register_action("move_left", [KEY_A, KEY_LEFT])
	_register_action("move_right", [KEY_D, KEY_RIGHT])
	_register_action("move_up", [KEY_W, KEY_UP])
	_register_action("move_down", [KEY_S, KEY_DOWN])
	_register_action("pause_game", [KEY_ESCAPE])
	_register_action("confirm_action", [KEY_ENTER, KEY_SPACE])


func _register_action(action: String, keys: Array[int]) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for key in keys:
		var event := InputEventKey.new()
		event.physical_keycode = key
		if not InputMap.action_has_event(action, event):
			InputMap.action_add_event(action, event)


func _load_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var error := save_data.load(SAVE_PATH)
		if error != OK:
			push_warning("Could not load ROAD RUSH save data: %s" % error_string(error))
			return
	var saved_profiles: Array = save_data.get_value("players", "profiles", [])
	profiles.clear()
	for saved_profile in saved_profiles:
		if saved_profile is Dictionary:
			profiles.append(saved_profile)
	active_profile_id = str(save_data.get_value("players", "active_id", ""))
	selected_character = str(save_data.get_value("settings", "character", "girl"))
	difficulty = str(save_data.get_value("settings", "difficulty", "normal"))
	music_enabled = bool(save_data.get_value("settings", "music_enabled", true))
	sfx_enabled = bool(save_data.get_value("settings", "sfx_enabled", true))
	best_score = int(save_data.get_value("records", "best_score", 0))
	has_survived = bool(save_data.get_value("records", "has_survived", false))
	fastest_arrival_time = float(save_data.get_value("records", "fastest_arrival_time", 0.0))
	fastest_arrival_name = str(save_data.get_value("records", "fastest_arrival_name", ""))
	highest_allowance = int(save_data.get_value("records", "highest_allowance", STARTING_ALLOWANCE))
	highest_allowance_name = str(save_data.get_value("records", "highest_allowance_name", ""))
	mini_game_longest_run = int(save_data.get_value("mini_game_records", "longest_run", 0))
	mini_game_highest_money_collected = int(save_data.get_value("mini_game_records", "highest_money_collected", 0))
	if selected_character not in ["girl", "boy"]:
		selected_character = "girl"
	if difficulty not in ["relaxed", "normal", "extreme"]:
		difficulty = "normal"
	if not _active_profile_exists():
		active_profile_id = ""
	_update_player_name()


func _save_data() -> void:
	save_data.set_value("players", "profiles", profiles)
	save_data.set_value("players", "active_id", active_profile_id)
	save_data.set_value("settings", "character", selected_character)
	save_data.set_value("settings", "difficulty", difficulty)
	save_data.set_value("settings", "music_enabled", music_enabled)
	save_data.set_value("settings", "sfx_enabled", sfx_enabled)
	save_data.set_value("records", "best_score", best_score)
	save_data.set_value("records", "has_survived", has_survived)
	save_data.set_value("records", "fastest_arrival_time", fastest_arrival_time)
	save_data.set_value("records", "fastest_arrival_name", fastest_arrival_name)
	save_data.set_value("records", "highest_allowance", highest_allowance)
	save_data.set_value("records", "highest_allowance_name", highest_allowance_name)
	save_data.set_value("mini_game_records", "longest_run", mini_game_longest_run)
	save_data.set_value("mini_game_records", "highest_money_collected", mini_game_highest_money_collected)
	var error := save_data.save(SAVE_PATH)
	if error != OK:
		push_error("Could not save ROAD RUSH data: %s" % error_string(error))


func _active_profile_exists() -> bool:
	for profile in profiles:
		if str(profile.get("id", "")) == active_profile_id:
			return true
	return false


func _update_player_name() -> void:
	player_name = "STUDENT"
	for profile in profiles:
		if str(profile.get("id", "")) == active_profile_id:
			player_name = str(profile.get("name", "STUDENT"))
			return


func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.is_action_pressed("pause_game"):
		if mode == "chase" or mode == "crossing":
			overlay = "" if overlay == "pause" else "pause"
			_refresh_ui()
			get_viewport().set_input_as_handled()
	elif event.is_action_pressed("confirm_action") and mode == "home" and overlay == "" and not intro_active:
		_start_new_cycle()


func _process(delta: float) -> void:
	world_time += delta
	_sync_audio_context()
	if intro_active:
		intro_elapsed = minf(INTRO_DURATION, intro_elapsed + delta)
		if intro_elapsed >= INTRO_DURATION:
			intro_active = false
			_play_sfx("start")
			home_reveal = 1.0
			screen_root.visible = true
	elif mode == "home" and home_reveal > 0.0:
		home_reveal = maxf(0.0, home_reveal - delta / 0.45)
	elif mode == "celebration":
		celebration_elapsed += delta
		if celebration_elapsed >= ARRIVAL_CELEBRATION_DURATION:
			_go_home()
	elif mode == "jaywalk_catch":
		jaywalk_catch_elapsed += delta
		if jaywalk_catch_elapsed >= JAYWALK_CATCH_DURATION:
			_start_chase()
	elif mode == "crossing" and overlay == "":
		_update_crossing(delta)
	elif mode == "chase" and overlay == "":
		_update_chase(delta)
	_sync_hud()
	queue_redraw()


func _update_crossing(delta: float) -> void:
	run_elapsed += delta
	var direction := Vector2(
		float(_movement_action_pressed("move_right")) - float(_movement_action_pressed("move_left")),
		float(_movement_action_pressed("move_down")) - float(_movement_action_pressed("move_up"))
	)
	if direction.length_squared() > 1.0:
		direction = direction.normalized()
	player_x = clampf(player_x + direction.x * 290.0 * delta, 14.0, VIEW_SIZE.x - PLAYER_SIZE.x - 14.0)
	player_y = clampf(player_y + direction.y * 290.0 * delta, 48.0, VIEW_SIZE.y - PLAYER_SIZE.y - 8.0)
	signal_elapsed += delta
	crossing_hit_timer = maxf(0.0, crossing_hit_timer - delta)

	var student_foot_y := player_y + PLAYER_SIZE.y - 4.0
	var on_road := student_foot_y > CROSSING_ROAD_TOP and student_foot_y < CROSSING_ROAD_BOTTOM
	if on_road and (not _signal_is_red() or not _on_painted_crosswalk()):
		crossing_jaywalking = true

	for vehicle in crossing_cars:
		vehicle["x"] = float(vehicle["x"]) + float(vehicle["speed"]) * _difficulty_multiplier() * delta
		var width := float(vehicle["width"])
		if float(vehicle["speed"]) > 0.0 and float(vehicle["x"]) > VIEW_SIZE.x + 160.0:
			vehicle["x"] = -width - rng.randf_range(100.0, 280.0)
		elif float(vehicle["speed"]) < 0.0 and float(vehicle["x"]) < -width - 160.0:
			vehicle["x"] = VIEW_SIZE.x + rng.randf_range(100.0, 280.0)
		if crossing_hit_timer <= 0.0 and _crossing_collision(vehicle):
			_play_sfx("crash")
			player_x = 716.0
			player_y = 390.0
			crossing_hit_timer = 1.1
			break
	_collect_crossing_coins()
	if player_y <= 52.0:
		if crossing_jaywalking:
			_begin_jaywalk_catch()
		else:
			_begin_arrival_celebration()


func _record_allowance() -> void:
	if wallet > highest_allowance:
		highest_allowance = wallet
		highest_allowance_name = player_name
		_save_data()


func _record_arrival() -> void:
	_record_allowance()
	if not crossing_jaywalking and run_elapsed > 0.0:
		if fastest_arrival_time <= 0.0 or run_elapsed < fastest_arrival_time:
			fastest_arrival_time = run_elapsed
			fastest_arrival_name = player_name
	_save_data()


func _begin_arrival_celebration() -> void:
	_record_arrival()
	_play_sfx("win")
	mode = "celebration"
	overlay = ""
	celebration_elapsed = 0.0
	screen_root.visible = false
	queue_redraw()


func _begin_jaywalk_catch() -> void:
	_record_arrival()
	_play_sfx("alert")
	mode = "jaywalk_catch"
	overlay = ""
	jaywalk_catch_elapsed = 0.0
	screen_root.visible = false
	queue_redraw()


func _time_record_text() -> String:
	if fastest_arrival_time <= 0.0:
		return "--:--"
	var total_seconds := int(ceil(fastest_arrival_time))
	return "%02d:%02d" % [total_seconds / 60, total_seconds % 60]


func _arrival_message() -> String:
	return "YOU MADE IT ON TIME!" if not crossing_jaywalking else "YOU MADE IT TO SCHOOL!"


func _signal_is_green() -> bool:
	return fposmod(signal_elapsed, SIGNAL_CYCLE_DURATION) < SIGNAL_GREEN_DURATION


func _signal_is_yellow() -> bool:
	var cycle_time := fposmod(signal_elapsed, SIGNAL_CYCLE_DURATION)
	return cycle_time >= SIGNAL_GREEN_DURATION and cycle_time < SIGNAL_GREEN_DURATION + SIGNAL_YELLOW_DURATION


func _signal_is_red() -> bool:
	return fposmod(signal_elapsed, SIGNAL_CYCLE_DURATION) >= SIGNAL_GREEN_DURATION + SIGNAL_YELLOW_DURATION


func _on_painted_crosswalk() -> bool:
	return player_x >= CROSSWALK_LEFT and player_x + PLAYER_SIZE.x <= CROSSWALK_RIGHT


func _collect_crossing_coins() -> void:
	var student_rect := Rect2(
		player_x + 7.0,
		player_y + 7.0,
		PLAYER_SIZE.x - 14.0,
		PLAYER_SIZE.y - 10.0
	)
	for coin_index in range(crossing_coins.size() - 1, -1, -1):
		var coin: Dictionary = crossing_coins[coin_index]
		var coin_rect := Rect2(Vector2(float(coin["x"]), float(coin["y"])), Vector2(18, 18))
		if student_rect.intersects(coin_rect):
			wallet += CROSSING_COIN_VALUE
			crossing_coins_collected += 1
			crossing_coins.remove_at(coin_index)
			_play_sfx("coin")
			_record_allowance()


func _crossing_collision(vehicle: Dictionary) -> bool:
	var width := float(vehicle["width"])
	var height := float(vehicle["height"])
	var vehicle_rect := Rect2(float(vehicle["x"]) + 4, float(vehicle["y"]) + 2, width - 8, height - 3)
	var student_rect := Rect2(player_x + 8, player_y + 34, PLAYER_SIZE.x - 16, 22)
	return vehicle_rect.intersects(student_rect)


func _update_chase(delta: float) -> void:
	run_elapsed += delta
	runner_elapsed += delta
	if not mini_game_mode:
		time_left = maxf(0.0, time_left - delta)
	var world_speed := minf(_base_speed() + runner_elapsed * 0.42, _base_speed() * 1.65)
	distance += world_speed * delta * 0.18
	road_offset = fposmod(road_offset + world_speed * delta, 96.0)
	stage = mini(6, int(runner_elapsed / 20.0) + 1)
	fee_popup_timer = maxf(0.0, fee_popup_timer - delta)

	var movement := Vector2(
		float(_movement_action_pressed("move_right")) - float(_movement_action_pressed("move_left")),
		float(_movement_action_pressed("move_down")) - float(_movement_action_pressed("move_up"))
	)
	if movement.length_squared() > 1.0:
		movement = movement.normalized()
	player_x = clampf(player_x + movement.x * 390.0 * delta, RUNNER_ROAD_LEFT + 8.0, RUNNER_ROAD_RIGHT - PLAYER_SIZE.x - 8.0)
	player_y = clampf(player_y + movement.y * 260.0 * delta, RUNNER_PLAYER_MIN_Y, RUNNER_PLAYER_MAX_Y)
	officer_x = move_toward(officer_x, player_x, 46.0 * delta)

	spawn_timer -= delta
	if spawn_timer <= 0.0:
		_spawn_traffic_row()
		spawn_timer = maxf(0.82, 1.48 - stage * 0.065) / _difficulty_multiplier()

	runner_coin_spawn_timer -= delta
	if runner_coin_spawn_timer <= 0.0:
		_spawn_runner_coin_row()
		runner_coin_spawn_timer = RUNNER_COIN_SPAWN_INTERVAL

	for hazard in hazards:
		var traffic_speed := world_speed * _difficulty_multiplier() * RUNNER_TRAFFIC_SPEED_MULTIPLIER * float(hazard.get("speed_scale", 1.0))
		hazard["y"] = float(hazard["y"]) + traffic_speed * delta
		if _runner_collision(hazard):
			_finish_capture()
			return
	hazards = hazards.filter(func(item: Dictionary) -> bool: return float(item["y"]) < VIEW_SIZE.y + 140.0)
	for coin in runner_coins:
		coin["y"] = float(coin["y"]) + world_speed * delta
	_collect_runner_coins()
	runner_coins = runner_coins.filter(func(coin: Dictionary) -> bool: return float(coin["y"]) < VIEW_SIZE.y + 24.0)
	if time_left <= 0.0 and not mini_game_mode:
		_finish_escape()


func _spawn_traffic_row() -> void:
	var gap_lane := rng.randi_range(0, RUNNER_LANES.size() - 1)
	var car_count := mini(3, 1 + int(stage / 2))
	var blocked_lanes: Array[int] = []
	while blocked_lanes.size() < car_count:
		var lane := rng.randi_range(0, RUNNER_LANES.size() - 1)
		if lane != gap_lane and not blocked_lanes.has(lane):
			blocked_lanes.append(lane)
	for lane_index in blocked_lanes:
		var is_jeepney := rng.randf() < 0.35
		var size := Vector2(rng.randf_range(66.0, 84.0), rng.randf_range(108.0, 126.0)) if is_jeepney else Vector2(rng.randf_range(48.0, 64.0), rng.randf_range(78.0, 96.0))
		hazards.append({
			"x": RUNNER_LANES[lane_index] - size.x / 2.0,
			"y": -float(size.y) - rng.randf_range(0.0, 38.0),
			"width": size.x,
			"height": size.y,
			"speed_scale": rng.randf_range(0.94, 1.06),
			"jeepney": is_jeepney,
			"color": CAR_COLORS[rng.randi_range(0, CAR_COLORS.size() - 1)],
		})


func _spawn_runner_coin_row(spawn_y: float = -18.0) -> void:
	var coin_count := rng.randi_range(1, 2)
	var lanes: Array[int] = []
	while lanes.size() < coin_count:
		var lane_index := rng.randi_range(0, RUNNER_LANES.size() - 1)
		if not lanes.has(lane_index):
			lanes.append(lane_index)
	for lane_index in lanes:
		runner_coins.append({
			"x": RUNNER_LANES[lane_index] - 9.0,
			"y": spawn_y,
		})


func _collect_runner_coins() -> void:
	var student_rect := Rect2(player_x + 7.0, player_y + 8.0, PLAYER_SIZE.x - 14.0, PLAYER_SIZE.y - 14.0)
	for coin_index in range(runner_coins.size() - 1, -1, -1):
		var coin: Dictionary = runner_coins[coin_index]
		var coin_rect := Rect2(Vector2(float(coin["x"]), float(coin["y"])), Vector2(18, 18))
		if student_rect.intersects(coin_rect):
			wallet += RUNNER_COIN_VALUE
			if mini_game_mode:
				mini_game_money_collected += RUNNER_COIN_VALUE
				_record_mini_game_scores()
			runner_coins.remove_at(coin_index)
			_play_sfx("coin")
			_record_allowance()


func _runner_collision(hazard: Dictionary) -> bool:
	var vehicle_rect := Rect2(
		float(hazard["x"]) + 4,
		float(hazard["y"]) + 6,
		float(hazard["width"]) - 8,
		float(hazard["height"]) - 12
	)
	var student_rect := Rect2(player_x + 7, player_y + 8, PLAYER_SIZE.x - 14, PLAYER_SIZE.y - 14)
	return vehicle_rect.intersects(student_rect)


func _finish_capture() -> void:
	_play_sfx("crash")
	if mini_game_mode:
		_record_mini_game_scores()
	else:
		best_score = maxi(best_score, int(distance))
		_record_arrival()
	if not mini_game_mode and time_left <= 0.0:
		runner_timed_out = true
		_play_sfx("gameover")
		overlay = "gameover"
		mode = "result"
		_refresh_ui()
		return
	if wallet >= 50:
		wallet -= 50
		_start_chase(mini_game_mode, mini_game_mode)
		return
	_play_sfx("gameover")
	overlay = "gameover"
	mode = "result"
	_refresh_ui()


func _finish_escape() -> void:
	if mini_game_mode:
		return
	has_survived = true
	best_score = maxi(best_score, int(distance))
	_begin_arrival_celebration()


func _record_mini_game_scores() -> void:
	var changed := false
	var run_distance := int(distance)
	if run_distance > mini_game_longest_run:
		mini_game_longest_run = run_distance
		changed = true
	if mini_game_money_collected > mini_game_highest_money_collected:
		mini_game_highest_money_collected = mini_game_money_collected
		changed = true
	if changed:
		_save_data()


func _difficulty_multiplier() -> float:
	match difficulty:
		"relaxed":
			return 0.78
		"extreme":
			return 1.38
		_:
			return 1.0


func _base_speed() -> float:
	match difficulty:
		"relaxed":
			return 185.0
		"extreme":
			return 268.0
		_:
			return 222.0


func _start_new_cycle() -> void:
	wallet = STARTING_ALLOWANCE
	attempts_remaining = STARTING_ATTEMPTS
	_start_crossing()


func _return_to_crossing() -> void:
	_start_crossing()


func _runner_officer_position() -> Vector2:
	var player_center_x := officer_x + 20.0
	var officer_left := player_center_x - 28.0 * RUNNER_OFFICER_SCALE
	return Vector2(officer_left, player_y + 75.0)


func _start_mini_game() -> void:
	if intro_active:
		return
	if profiles.size() > 0 and not _active_profile_exists():
		overlay = "profile"
		_refresh_ui()
		return
	wallet = STARTING_ALLOWANCE
	attempts_remaining = STARTING_ATTEMPTS
	run_elapsed = 0.0
	mini_game_money_collected = 0
	crossing_jaywalking = false
	_start_chase(true)


func _start_crossing() -> void:
	if intro_active:
		return
	if profiles.size() > 0 and not _active_profile_exists():
		overlay = "profile"
		_refresh_ui()
		return
	_play_sfx("start")
	mode = "crossing"
	overlay = ""
	player_x = 716.0
	player_y = 390.0
	run_elapsed = 0.0
	crossing_hit_timer = 0.0
	signal_elapsed = 0.0
	crossing_jaywalking = false
	crossing_coins_collected = 0
	crossing_coins = [
		{"x": 80.0, "y": 150.0},
		{"x": 850.0, "y": 150.0},
		{"x": 350.0, "y": 218.0},
		{"x": 640.0, "y": 218.0},
		{"x": 80.0, "y": 292.0},
		{"x": 260.0, "y": 292.0},
		{"x": 850.0, "y": 292.0},
	]
	crossing_cars = [
		{"x": -80.0, "y": 112.0, "width": 92.0, "height": 34.0, "speed": 190.0, "color": Color("#ed614b")},
		{"x": 390.0, "y": 112.0, "width": 92.0, "height": 34.0, "speed": 190.0, "color": Color("#d4a349")},
		{"x": 180.0, "y": 178.0, "width": 88.0, "height": 34.0, "speed": -164.0, "color": Color("#69bed2")},
		{"x": 720.0, "y": 178.0, "width": 88.0, "height": 34.0, "speed": -164.0, "color": Color("#bd7868")},
		{"x": 30.0, "y": 244.0, "width": 124.0, "height": 42.0, "speed": 132.0, "color": Color("#1768b7"), "jeepney": true},
		{"x": 590.0, "y": 244.0, "width": 124.0, "height": 42.0, "speed": 132.0, "color": Color("#1768b7"), "jeepney": true},
		{"x": 300.0, "y": 330.0, "width": 148.0, "height": 38.0, "speed": -210.0, "color": Color("#e6bb44")},
		{"x": 830.0, "y": 330.0, "width": 78.0, "height": 32.0, "speed": -210.0, "color": Color("#73a779")},
		{"x": -20.0, "y": 374.0, "width": 82.0, "height": 34.0, "speed": 168.0, "color": Color("#a388c0")},
		{"x": 500.0, "y": 374.0, "width": 156.0, "height": 38.0, "speed": 168.0, "color": Color("#d98770")},
	]
	_refresh_ui()


func _start_chase(is_mini_game: bool = false, reset_timer: bool = true) -> void:
	_play_sfx("start")
	mode = "chase"
	overlay = ""
	mini_game_mode = is_mini_game
	if reset_timer:
		time_left = RUN_DURATION
		runner_timed_out = false
	player_x = RUNNER_LANES[2] - PLAYER_SIZE.x * 0.5
	player_y = RUNNER_PLAYER_Y
	officer_x = player_x
	distance = 0.0
	stage = 1
	road_offset = 0.0
	spawn_timer = 1.0
	fee_popup_timer = 0.0
	runner_elapsed = 0.0
	hazards.clear()
	runner_coins.clear()
	_spawn_runner_coin_row(40.0)
	_spawn_runner_coin_row(-120.0)
	_spawn_runner_coin_row(-280.0)
	runner_coin_spawn_timer = RUNNER_COIN_SPAWN_INTERVAL
	_refresh_ui()


func _go_home() -> void:
	if mini_game_mode:
		_record_mini_game_scores()
	mode = "home"
	overlay = ""
	mini_game_mode = false
	home_reveal = 0.0
	_refresh_ui()


func _refresh_ui() -> void:
	virtual_move_actions.clear()
	for child in ui_root.get_children():
		child.queue_free()
	hud_labels.clear()
	screen_root = Control.new()
	screen_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(screen_root)

	match mode:
		"home":
			_build_home()
		"crossing":
			_build_crossing_hud()
		"chase":
			_build_chase_hud()
		"crossing_reward":
			_build_crossing_hud()
		"result":
			_build_chase_hud()
	if overlay != "":
		_build_overlay()
	_sync_hud()


func _sync_hud() -> void:
	if hud_labels.has("wallet"):
		hud_labels["wallet"].text = "₱%d" % wallet
	if hud_labels.has("attempts"):
		hud_labels["attempts"].text = "ATTEMPTS %d/3" % attempts_remaining
	if hud_labels.has("timer"):
		if mini_game_mode:
			hud_labels["timer"].text = "COINS ₱%d" % mini_game_money_collected
		else:
			hud_labels["timer"].text = "%02d:%02d" % [int(time_left) / 60, int(time_left) % 60]
	if hud_labels.has("distance"):
		hud_labels["distance"].text = "%04d m" % int(distance)
	if hud_labels.has("stage"):
		hud_labels["stage"].text = "STAGE %d/6" % stage
	if hud_labels.has("fee"):
		hud_labels["fee"].visible = fee_popup_timer > 0.0


func _build_home() -> void:
	var menu_panel := PanelContainer.new()
	menu_panel.position = Vector2(328, 244)
	menu_panel.size = Vector2(304, 278)
	menu_panel.mouse_filter = Control.MOUSE_FILTER_PASS
	_apply_panel_style(menu_panel, Color("#503226"), Color("#111e39"))
	screen_root.add_child(menu_panel)

	var menu := VBoxContainer.new()
	menu.add_theme_constant_override("separation", 6)
	menu_panel.add_child(menu)

	var start_text := "▶   START GAME"
	if not _active_profile_exists() and profiles.size() > 0:
		start_text = "▶   CHOOSE PLAYER"
	_add_home_menu_button(menu, start_text, _start_new_cycle, Color("#ffd13d"), Color("#17233c"), 36)
	_add_home_menu_button(menu, "RUNNER CHALLENGE", _start_mini_game, Color("#b8493d"), Color("#fff2d4"), 32)
	_add_home_menu_button(menu, "SELECT CHARACTER", func() -> void: _open_overlay("character"), Color("#744530"), Color("#fff2d4"), 34)
	_add_home_menu_button(menu, "OPTIONS", func() -> void: _open_overlay("options"), Color("#744530"), Color("#fff2d4"), 34)
	_add_home_menu_button(menu, "ACHIEVEMENTS", func() -> void: _open_overlay("achievements"), Color("#744530"), Color("#fff2d4"), 34)
	_add_home_menu_button(menu, "HOW TO PLAY", func() -> void: _open_overlay("help"), Color("#744530"), Color("#fff2d4"), 34)

	var profile_name := player_name if _active_profile_exists() else "PLAYER PROFILE"
	var profile_button := _add_button(screen_root, profile_name, func() -> void: _open_overlay("profile"), Color("#27647b"), 34)
	profile_button.position = Vector2(782, 17)
	profile_button.size = Vector2(160, 34)
	profile_button.add_theme_font_size_override("font_size", 11)

	var hint := _add_label(screen_root, "MINI GAME  •  LONGEST RUN %d m  •  MONEY COLLECTED ₱%d" % [mini_game_longest_run, mini_game_highest_money_collected], 10, Color("#fff4d7"))
	hint.position = Vector2(304, 511)
	hint.size = Vector2(450, 23)


func _add_home_menu_button(parent: Control, text_value: String, callback: Callable, color: Color, text_color: Color, height: float) -> Button:
	var button: Button = ui_style.add_home_button(parent, text_value, callback, color, text_color, height)
	button.button_down.connect(func() -> void: _play_sfx("click"))
	return button


func _popup_button_color(original: Color) -> Color:
	return ui_style.popup_button_color(original)


func _home_button_style(color: Color) -> StyleBoxFlat:
	return ui_style.home_button_style(color)


func _build_crossing_hud() -> void:
	var top := _hud_bar("₱%d" % wallet, "ATTEMPTS %d/3" % attempts_remaining)
	hud_labels["wallet"] = top.get_node("WalletCard/WalletValue")
	hud_labels["attempts"] = top.get_node("AttemptsCard/AttemptsValue")
	var pause_button := _add_button(top, "PAUSE", func() -> void: _open_overlay("pause"), Color("#8e4c36"), 40)
	_configure_pause_button(pause_button)
	var hint := _add_label(screen_root, "BROKEN LIGHT: GREEN = JAYWALK  •  WAIT FOR RED  •  STAY ON WHITE PAINT  •  COINS +₱5", 10, Color("#fff2c6"))
	hint.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hint.size = Vector2(620, 26)
	hint.custom_minimum_size = Vector2(620, 26)
	hint.position = Vector2(-310, 66)
	hint.add_theme_color_override("font_outline_color", Color("#332b30"))
	hint.add_theme_constant_override("outline_size", 2)
	_build_wasd_guide()


func _build_chase_hud() -> void:
	var bar := _hud_bar("₱%d" % wallet, "FINE ₱50")
	var timer_text := "COINS ₱%d" % mini_game_money_collected if mini_game_mode else "02:00"
	var timer := _add_label(bar, timer_text, 18, Color("#ffe074"))
	timer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hud_labels["timer"] = timer
	var pause_button := _add_button(bar, "PAUSE", func() -> void: _open_overlay("pause"), Color("#8e4c36"), 40)
	_configure_pause_button(pause_button)
	hud_labels["wallet"] = bar.get_node("WalletValue")
	hud_labels["distance"] = bar.get_node("DistanceValue")
	var hint_text := "MINI GAME  •  RUN AS FAR AS POSSIBLE  •  COLLECT COINS +₱2  •  FINE ₱50" if mini_game_mode else "SANGTIANKO STREET  •  DODGE TRAFFIC  •  COLLECT COINS +₱2  •  REACH CAMPUS IN TWO MINUTES"
	var hint := _add_label(screen_root, hint_text, 9, Color("#fff2c6"))
	hint.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hint.position = Vector2(-330, 66)
	hint.size = Vector2(660, 24)
	var stage_label := _add_label(screen_root, "STAGE 1/6", 10, Color("#fff2c6"))
	stage_label.position = Vector2(20, 508)
	stage_label.size = Vector2(130, 20)
	hud_labels["stage"] = stage_label
	var fee := _add_label(screen_root, "TRAFFIC FINE   −₱50", 15, Color("#fff1d1"))
	fee.set_anchors_preset(Control.PRESET_CENTER_TOP)
	fee.position = Vector2(-180, 72)
	fee.size = Vector2(360, 34)
	fee.custom_minimum_size = Vector2(360, 34)
	fee.visible = false
	hud_labels["fee"] = fee
	if mode == "chase":
		_build_wasd_guide()


func _build_wasd_guide() -> void:
	var guide := Control.new()
	guide.name = "WASDControlsGuide"
	guide.position = Vector2(VIEW_SIZE.x - WASD_GUIDE_SIZE.x - 12.0, VIEW_SIZE.y - WASD_GUIDE_SIZE.y - 8.0)
	guide.size = WASD_GUIDE_SIZE
	guide.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_root.add_child(guide)

	var keys := GridContainer.new()
	keys.name = "WASDKeyLayout"
	keys.columns = 3
	keys.position = Vector2(3, 2)
	keys.add_theme_constant_override("h_separation", 4)
	keys.add_theme_constant_override("v_separation", 5)
	keys.mouse_filter = Control.MOUSE_FILTER_IGNORE
	guide.add_child(keys)
	_add_wasd_placeholder(keys, "TopLeftSpacer")
	_add_wasd_keycap(keys, "W")
	_add_wasd_placeholder(keys, "TopRightSpacer")
	_add_wasd_keycap(keys, "A")
	_add_wasd_keycap(keys, "S")
	_add_wasd_keycap(keys, "D")


func _add_wasd_placeholder(parent: Control, placeholder_name: String) -> void:
	var placeholder := Control.new()
	placeholder.name = placeholder_name
	placeholder.custom_minimum_size = WASD_KEY_SIZE
	placeholder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(placeholder)


func _add_wasd_keycap(parent: Control, key_text: String) -> void:
	var action := str(WASD_ACTIONS[key_text])
	var keycap: Button = ui_style.add_keycap(
		parent,
		key_text,
		Callable(self, "_set_virtual_movement").bind(action, true),
		Callable(self, "_set_virtual_movement").bind(action, false)
	)
	keycap.name = "Key" + key_text
	keycap.custom_minimum_size = WASD_KEY_SIZE


func _set_virtual_movement(action: String, pressed: bool) -> void:
	virtual_move_actions[action] = pressed


func _movement_action_pressed(action: String) -> bool:
	return Input.is_action_pressed(action) or bool(virtual_move_actions.get(action, false))


func _hud_bar(left_text: String, middle_text: String) -> HBoxContainer:
	var bar := HBoxContainer.new()
	bar.set_anchors_preset(Control.PRESET_TOP_WIDE)
	bar.offset_left = 14
	bar.offset_top = 12
	bar.offset_right = -14
	bar.offset_bottom = 64
	bar.add_theme_constant_override("separation", 16)
	_apply_panel_style(bar, Color("#173949"), Color("#dfb951"))
	screen_root.add_child(bar)

	if mode == "chase" or mode == "result":
		var wallet_value := _add_label(bar, left_text, 19, Color("#ffd54f"))
		wallet_value.name = "WalletValue"
		wallet_value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var attempts_value := _add_label(bar, middle_text, 15, Color("#ffffff"))
		attempts_value.name = "AttemptsValue"
		attempts_value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var distance_value := _add_label(bar, "%04d m" % int(distance), 15, Color("#ffffff"))
		distance_value.name = "DistanceValue"
		distance_value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	else:
		_add_crossing_counter(bar, "WalletCard", "WalletValue", left_text, 16)
		_add_crossing_counter(bar, "AttemptsCard", "AttemptsValue", middle_text, 14)
		var spacer := Control.new()
		spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bar.add_child(spacer)
	return bar


func _add_crossing_counter(parent: Control, card_name: String, value_name: String, value_text: String, font_size: int) -> Label:
	var card := PanelContainer.new()
	card.name = card_name
	var card_width := 110.0 if value_name == "WalletValue" else 170.0
	card.custom_minimum_size = Vector2(card_width, 42)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#70472f")
	style.border_color = Color("#deb35d")
	style.set_border_width_all(3)
	style.set_corner_radius_all(0)
	style.shadow_color = Color("#241a1b")
	style.shadow_size = 2
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 2
	style.content_margin_bottom = 2
	card.add_theme_stylebox_override("panel", style)
	parent.add_child(card)
	var value := _add_label(card, value_text, font_size, Color("#ffd54f"))
	value.name = value_name
	value.autowrap_mode = TextServer.AUTOWRAP_OFF
	value.clip_text = false
	value.add_theme_color_override("font_outline_color", Color("#332b30"))
	value.add_theme_constant_override("outline_size", 2)
	return value


func _configure_pause_button(button: Button) -> void:
	button.custom_minimum_size = Vector2(174, 52)
	button.size_flags_horizontal = Control.SIZE_SHRINK_END
	button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	button.add_theme_font_size_override("font_size", 14)


func _open_overlay(name: String) -> void:
	overlay = name
	_refresh_ui()


func _build_profile_panel(body: VBoxContainer) -> void:
	_add_label(body, "Up to three local players share this device.", 13, Color("#52645e"))
	for index in range(profiles.size()):
		var profile := profiles[index]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		body.add_child(row)
		var detail := "%d. %s   •   AGE %d   •   %s" % [
			index + 1,
			str(profile.get("name", "PLAYER")),
			int(profile.get("age", 0)),
			str(profile.get("sex", ""))
		]
		var choose := _add_button(row, detail, _select_profile.bind(str(profile.get("id", ""))), Color("#287660"), 42)
		choose.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_add_button(row, "DELETE", _delete_profile.bind(str(profile.get("id", ""))), Color("#9a4b37"), 42)
	if profiles.size() < 3:
		_add_button(body, "ADD PLAYER", func() -> void: _open_overlay("create_profile"), Color("#276c76"))
	if profiles.is_empty():
		_add_label(body, "No profile yet. Add one or play as STUDENT.", 13, Color("#52645e"))


func _build_character_panel(body: VBoxContainer) -> void:
	_add_label(body, "Student uniforms inspired by Cebu school life.", 13, Color("#52645e"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(row)
	_add_character_card(row, "girl", "GIRL", "UV skirt uniform", GIRL_TEXTURE)
	_add_character_card(row, "boy", "BOY", "UV trouser uniform", BOY_TEXTURE)


func _add_character_card(parent: HBoxContainer, key: String, title: String, description: String, texture: Texture2D) -> void:
	var card := VBoxContainer.new()
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.add_theme_constant_override("separation", 5)
	parent.add_child(card)
	var image := TextureRect.new()
	image.texture = texture
	image.custom_minimum_size = Vector2(130, 150)
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	card.add_child(image)
	_add_label(card, title, 17, Color("#173949"))
	_add_label(card, description, 11, Color("#52645e"))
	var text := "SELECTED" if selected_character == key else "SELECT"
	_add_button(card, text, func() -> void:
		selected_character = key
		_save_data()
		_open_overlay("character")
	, Color("#287660") if selected_character == key else Color("#276c76"), 38)


func _build_options_panel(body: VBoxContainer) -> void:
	_add_label(body, "AUDIO", 14, Color("#287660"))
	_add_button(body, "MUSIC: %s" % ("ON" if music_enabled else "OFF"), _toggle_music, Color("#319274") if music_enabled else Color("#7a6258"), 40)
	_add_button(body, "SOUND EFFECTS: %s" % ("ON" if sfx_enabled else "OFF"), _toggle_sfx, Color("#276c76") if sfx_enabled else Color("#7a6258"), 40)
	_add_label(body, "DIFFICULTY", 14, Color("#287660"))
	_add_label(body, "Difficulty changes movement and pursuit speed.", 12, Color("#52645e"))
	_add_button(body, "RELAXED  •  SLOWER TRAFFIC", func() -> void: _set_difficulty("relaxed"), Color("#319274"), 40)
	_add_button(body, "NORMAL  •  FULL ROAD RUSH", func() -> void: _set_difficulty("normal"), Color("#276c76"), 40)
	_add_button(body, "MONDAY RUSH  •  EXTREME", func() -> void: _set_difficulty("extreme"), Color("#9a4b37"), 40)
	_add_label(body, "CURRENT: %s" % difficulty.to_upper(), 12, Color("#b77812"))


func _build_achievements_panel(body: VBoxContainer) -> void:
	_add_achievement_section(body, "ROAD RUSH RECORDS")
	_add_achievement_record(body, "FASTEST ON-TIME", _time_record_text(), _record_holder(fastest_arrival_name))
	_add_achievement_record(body, "HIGHEST ALLOWANCE", "₱%d" % highest_allowance, _record_holder(highest_allowance_name))

	_add_achievement_section(body, "PERSONAL BESTS")
	_add_achievement_record(body, "BEST RUN", "%d m" % best_score)

	_add_achievement_section(body, "ACHIEVEMENTS")
	_add_achievement(body, "THE CHASE BEGINS", "Reach the far sidewalk.", mode == "chase" or has_survived or best_score > 0)
	_add_achievement(body, "CAMPUS BOUND", "Survive the two-minute traffic chase.", has_survived)
	_add_achievement(body, "ROAD RUNNER", "Travel at least 500 m in one run.", best_score >= 500)

	_add_achievement_section(body, "MINI GAME LEADERBOARD")
	_add_achievement_record(body, "LONGEST RUN", " %d m" % mini_game_longest_run)
	_add_achievement_record(body, "HIGHEST MONEY COLLECTED", "₱ %d" % mini_game_highest_money_collected)
	_add_label(body, "Mini-game records are separate from ROAD RUSH records.", 11, Color("#52645e"))


func _add_achievement_section(parent: VBoxContainer, title_text: String) -> void:
	var heading := PanelContainer.new()
	heading.custom_minimum_size.y = 32
	_apply_panel_style(heading, Color("#285363"), Color("#142f48"))
	var label := _add_label(heading, title_text, 13, Color("#fff3d6"))
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.add_theme_constant_override("outline_size", 1)
	label.add_theme_color_override("font_outline_color", Color("#173949"))
	parent.add_child(heading)


func _add_achievement_record(parent: VBoxContainer, title_text: String, value_text: String, holder_text: String = "") -> void:
	var row := PanelContainer.new()
	row.custom_minimum_size.y = 42 if holder_text.is_empty() else 54
	_apply_panel_style(row, Color("#f1e3c3"), Color("#c39a50"))

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 8)
	row.add_child(columns)

	var title_column := VBoxContainer.new()
	title_column.add_theme_constant_override("separation", 0)
	title_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(title_column)
	var title := _add_label(title_column, title_text, 11, Color("#52645e"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	if not holder_text.is_empty():
		var holder := _add_label(title_column, holder_text, 10, Color("#7c8078"))
		holder.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT

	var value := _add_label(columns, value_text, 16, Color("#173949"))
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value.size_flags_horizontal = Control.SIZE_SHRINK_END
	parent.add_child(row)


func _record_holder(name: String) -> String:
	return name if not name.is_empty() else "NO RECORD"


func _add_achievement(parent: VBoxContainer, title: String, detail: String, unlocked: bool) -> void:
	var row := PanelContainer.new()
	row.custom_minimum_size.y = 48
	_apply_panel_style(row, Color("#e8eedb") if unlocked else Color("#ede6d8"), Color("#77a37a") if unlocked else Color("#b3aa98"))
	var content := HBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	row.add_child(content)
	var status := _add_label(content, "✓" if unlocked else "○", 18, Color("#287660") if unlocked else Color("#8b897f"))
	status.size_flags_horizontal = Control.SIZE_SHRINK_END
	status.custom_minimum_size.x = 28
	var text := VBoxContainer.new()
	text.add_theme_constant_override("separation", 0)
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_child(text)
	var title_label := _add_label(text, title, 12, Color("#287660") if unlocked else Color("#69736d"))
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	var detail_label := _add_label(text, detail, 10, Color("#52645e"))
	detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	parent.add_child(row)


func _build_help_panel(body: VBoxContainer) -> void:
	_add_label(body, "CROSS SANCIANGCO STREET", 14, Color("#287660"))
	_add_label(body, "Move with WASD or arrows. Green and yellow mean jaywalking. Cross only on red and stay inside the faded white crossing for the whole road.", 12, Color("#52645e"))
	_add_label(body, "Collect ₱5 coins across the road. Some coins tempt you off the worn crossing into traffic.", 12, Color("#52645e"))
	_add_label(body, "Being on the road during green or yellow, or leaving the white crossing, triggers a three-second officer-catch scene and sends you into the traffic chase.", 12, Color("#52645e"))
	_add_label(body, "2. RUN FROM THE TRAFFIC", 14, Color("#287660"))
	_add_label(body, "Use WASD or arrows to steer and move up/down while dodging cars and jeepneys for two minutes.", 12, Color("#52645e"))
	_add_label(body, "Collect moving chase coins for ₱2 each while the officer runs behind you.", 12, Color("#52645e"))
	_add_label(body, "3. PROTECT YOUR ALLOWANCE", 14, Color("#287660"))
	_add_label(body, "Start with ₱150. A crash automatically costs ₱50 and restarts the chase if you can pay. With less than ₱50, return to the crossing and collect more coins.", 12, Color("#52645e"))
	_add_label(body, "The standalone MINI GAME has no timer: keep running and collecting coins until you cannot pay another ₱50 fine. Its longest-run and total-money records are on a separate leaderboard.", 12, Color("#52645e"))


func _build_overlay() -> void:
	var dim := ColorRect.new()
	dim.name = "PopupDimmer"
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.018, 0.045, 0.09, 0.82)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	screen_root.add_child(dim)

	var card := PanelContainer.new()
	card.name = "ArcadePopup"
	var card_size := _popup_size()
	card.set_anchors_preset(Control.PRESET_TOP_LEFT)
	card.position = (VIEW_SIZE - card_size) * 0.5
	card.size = card_size
	card.custom_minimum_size = card_size
	_apply_pixel_popup_style(card, Color("#fff5dc"), _popup_accent())
	screen_root.add_child(card)

	var layout := VBoxContainer.new()
	layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	layout.size_flags_vertical = Control.SIZE_EXPAND_FILL
	layout.add_theme_constant_override("separation", 6)
	card.add_child(layout)

	var header := PanelContainer.new()
	header.custom_minimum_size.y = 54
	_apply_pixel_popup_style(header, _popup_accent(), Color("#142746"))
	layout.add_child(header)

	var header_row := HBoxContainer.new()
	header_row.add_theme_constant_override("separation", 8)
	header.add_child(header_row)
	var pixel_badge := HBoxContainer.new()
	pixel_badge.name = "PixelBadge"
	pixel_badge.add_theme_constant_override("separation", 2)
	header_row.add_child(pixel_badge)
	for pixel_color in [Color("#ffd13d"), Color("#fff5dc"), Color("#72e0ad")]:
		var pixel := ColorRect.new()
		pixel.color = pixel_color
		pixel.custom_minimum_size = Vector2(7, 7)
		pixel_badge.add_child(pixel)
	var title_color := Color("#ffd13d") if overlay == "gameover" else Color("#ffffff")
	var title := _add_label(header_row, _popup_title(), 22, title_color)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_outline_color", Color("#142746"))
	title.add_theme_constant_override("outline_size", 2)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(spacer)
	var close := Button.new()
	close.text = "X"
	close.custom_minimum_size = Vector2(36, 34)
	close.add_theme_font_size_override("font_size", 14)
	close.add_theme_color_override("font_color", Color("#ffffff"))
	close.add_theme_stylebox_override("normal", _pixel_button_style(Color("#17354e")))
	close.add_theme_stylebox_override("hover", _pixel_button_style(Color("#345872")))
	close.add_theme_stylebox_override("pressed", _pixel_button_style(Color("#10243b")))
	close.pressed.connect(_popup_back)
	close.button_down.connect(func() -> void: _play_sfx("click"))
	if overlay != "gameover" or not mini_game_mode:
		header_row.add_child(close)
	else:
		close.queue_free()

	var accent_rule := ColorRect.new()
	accent_rule.color = _popup_accent().lightened(0.18)
	accent_rule.custom_minimum_size.y = 4
	layout.add_child(accent_rule)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if overlay == "pause":
		scroll.custom_minimum_size.y = 200
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	layout.add_child(scroll)

	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 6)
	scroll.add_child(body)

	building_popup = true

	match overlay:
		"profile":
			_build_profile_panel(body)
		"create_profile":
			_build_create_profile_panel(body)
		"character":
			_build_character_panel(body)
		"options":
			_build_options_panel(body)
		"achievements":
			_build_achievements_panel(body)
		"help":
			_build_help_panel(body)
		"pause":
			_add_label(body, "Take a breather, then beat the traffic.", 13, Color("#52645e"))
			_add_button(body, "RESUME GAME", func() -> void: _close_overlay(), Color("#319274"))
			_add_button(body, "OPTIONS", func() -> void: _open_overlay("options"), Color("#276c76"))
			_add_button(body, "MAIN MENU", _go_home, Color("#9a4b37"))
			_add_button(body, "QUIT GAME", func() -> void: get_tree().quit(), Color("#9a4b37"))
		"allowance":
			if crossing_jaywalking:
				_add_label(body, "LATE TO CLASS — JAYWALKING!", 20, Color("#a73e37"))
				_add_label(body, "You reached the far side, but crossed on green or left the faded white crossing.", 13, Color("#52645e"))
				_add_button(body, "START THE CHASE", _start_chase, Color("#e7b93e"), 52)
			else:
				_add_label(body, "PASSED! YOU'RE ON TIME!", 20, Color("#1a6048"))
				_add_label(body, "You waited for red and stayed on the worn white crossing. Make it to campus!", 13, Color("#52645e"))
				_add_label(body, "COINS  +₱%d     ALLOWANCE  ₱%d     ATTEMPTS  %d/3" % [crossing_coins_collected * CROSSING_COIN_VALUE, wallet, attempts_remaining], 16, Color("#b77812"))
				_add_button(body, "START THE CHASE", _start_chase, Color("#e7b93e"), 52)
		"won":
			_add_label(body, "YOU REACHED CAMPUS!", 22, Color("#1a6048"))
			_add_label(body, "You outlasted the traffic and escaped the officer.", 13, Color("#52645e"))
			_add_label(body, "DISTANCE  %d m     ALLOWANCE  ₱%d" % [int(distance), wallet], 18, Color("#b77812"))
			_add_button(body, "START A NEW CYCLE", _start_new_cycle, Color("#e7b93e"))
			_add_button(body, "MAIN MENU", _go_home, Color("#276c76"))
		"gameover":
			if mini_game_mode:
				_add_label(body, "OUT OF ALLOWANCE — RUN ENDED", 12, Color("#52645e"))
				var stats := HBoxContainer.new()
				stats.add_theme_constant_override("separation", 8)
				body.add_child(stats)
				_add_popup_stat(stats, "RUN DISTANCE", "%d m" % int(distance), Color("#f2a62b"), "RunDistance")
				_add_popup_stat(stats, "COINS COLLECTED", "₱%d" % mini_game_money_collected, Color("#149873"), "Coins")
				_add_label(body, "BEST RUN  %d m     BEST COINS  ₱%d" % [mini_game_longest_run, mini_game_highest_money_collected], 12, Color("#8e5f17"))
				_add_button(body, "RUN AGAIN", _start_mini_game, Color("#e7b93e"), 48)
				_add_button(body, "MAIN MENU", _go_home, Color("#9a4b37"), 40)
			elif runner_timed_out:
				_add_label(body, "TIME RAN OUT!", 20, Color("#a73e37"))
				_add_label(body, "The two-minute rush ended before the student escaped the traffic.", 13, Color("#52645e"))
				_add_label(body, "DISTANCE  %d m     ALLOWANCE  ₱%d" % [int(distance), wallet], 16, Color("#b77812"))
				_add_button(body, "RETURN TO CROSSING", _return_to_crossing, Color("#e7b93e"), 46)
				_add_button(body, "MAIN MENU", _go_home, Color("#9a4b37"), 40)
			else:
				_add_label(body, "YOU CAN'T PAY THE FINE", 12, Color("#52645e"))
				var stats := HBoxContainer.new()
				stats.add_theme_constant_override("separation", 8)
				body.add_child(stats)
				_add_popup_stat(stats, "DISTANCE", "%d m" % int(distance), Color("#f2a62b"), "RunDistance")
				_add_popup_stat(stats, "ALLOWANCE", "₱%d" % wallet, Color("#149873"), "Allowance")
				_add_label(body, "COLLECT MORE COINS TO GET BACK IN THE RACE", 11, Color("#52645e"))
				_add_button(body, "▶  RETURN TO CROSSING", _return_to_crossing, Color("#e7b93e"), 46)
				_add_button(body, "MAIN MENU", _go_home, Color("#9a4b37"), 40)
		_:
			_add_label(body, "ROAD RUSH", 22, Color("#173949"))
			_add_button(body, "CLOSE", func() -> void: _close_overlay(), Color("#276c76"))

	building_popup = false
	if overlay not in ["pause", "allowance", "won", "gameover"]:
		var footer_rule := ColorRect.new()
		footer_rule.color = Color("#c5d9dd")
		footer_rule.custom_minimum_size.y = 2
		layout.add_child(footer_rule)
		_add_button(layout, "BACK", _popup_back, Color("#8e4c36"), 38)


func _popup_back() -> void:
	if overlay == "create_profile":
		_open_overlay("profile")
	else:
		_close_overlay()


func _popup_title() -> String:
	match overlay:
		"profile":
			return "PLAYER PROFILE"
		"create_profile":
			return "CREATE PLAYER"
		"character":
			return "CHARACTER SELECT"
		"options":
			return "SETTINGS"
		"achievements":
			return "ACHIEVEMENTS"
		"help":
			return "HOW TO PLAY"
		"pause":
			return "PAUSED"
		"allowance":
			return "LATE TO CLASS!" if crossing_jaywalking else "CROSSING PASSED!"
		"won":
			return "LEVEL COMPLETE!"
		"gameover":
			return "GAME OVER" if mini_game_mode else "GAME OVER"
		_:
			return "ROAD RUSH"


func _popup_size() -> Vector2:
	match overlay:
		"profile":
			return Vector2(500, 340)
		"create_profile":
			return Vector2(420, 350)
		"character":
			return Vector2(520, 390)
		"options":
			return Vector2(420, 360)
		"achievements":
			return Vector2(550, 400)
		"help":
			return Vector2(650, 420)
		"pause":
			return Vector2(340, 320)
		"allowance":
			return Vector2(480, 330)
		"won":
			return Vector2(460, 310)
		"gameover":
			return Vector2(500, 370)
		_:
			return Vector2(480, 340)


func _add_popup_stat(parent: Control, caption: String, value: String, value_color: Color, key: String) -> void:
	var card := PanelContainer.new()
	card.name = "PopupStat" + key
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card.custom_minimum_size = Vector2(0, 78)
	_apply_pixel_popup_style(card, Color("#fff0bf"), Color("#17233d"))
	parent.add_child(card)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 0)
	card.add_child(content)
	var heading := _add_label(content, caption, 10, Color("#29334a"))
	heading.clip_text = true
	var amount := _add_label(content, value, 22, value_color)
	amount.add_theme_color_override("font_outline_color", Color("#fffaf0"))
	amount.add_theme_constant_override("outline_size", 1)


func _popup_accent() -> Color:
	match overlay:
		"gameover":
			return Color("#ec3150")
		"won":
			return Color("#11aa70")
		"allowance":
			return Color("#e7b426")
		"pause":
			return Color("#168dd6")
		_:
			return Color("#078de0")


func _apply_pixel_popup_style(control: Control, background: Color, border: Color) -> void:
	ui_style.apply_pixel_popup_style(control, background, border)


func _pixel_button_style(background: Color) -> StyleBoxFlat:
	return ui_style.pixel_button_style(background)


func _build_create_profile_panel(body: VBoxContainer) -> void:
	_add_label(body, "Your profile stays on this device.", 13, Color("#52645e"))
	var name_input := LineEdit.new()
	name_input.name = "ProfileName"
	name_input.placeholder_text = "PLAYER NAME (14 CHARACTERS)"
	name_input.max_length = 14
	name_input.custom_minimum_size.y = 42
	body.add_child(name_input)
	var age_input := SpinBox.new()
	age_input.name = "ProfileAge"
	age_input.min_value = 5
	age_input.max_value = 99
	age_input.value = 12
	age_input.prefix = "AGE  "
	age_input.custom_minimum_size.y = 40
	body.add_child(age_input)
	var sex_input := OptionButton.new()
	sex_input.name = "ProfileSex"
	sex_input.add_item("Female", 0)
	sex_input.add_item("Male", 1)
	sex_input.custom_minimum_size.y = 40
	body.add_child(sex_input)
	_add_button(body, "SAVE PLAYER", func() -> void:
		var name_text := name_input.text.strip_edges()
		if name_text.is_empty():
			_add_label(body, "Enter a name before saving.", 12, Color("#b03e37"))
			return
		var profile_id := str(Time.get_unix_time_from_system()) + "-" + str(rng.randi())
		profiles.append({"id": profile_id, "name": name_text, "age": int(age_input.value), "sex": sex_input.get_item_text(sex_input.selected).to_lower()})
		active_profile_id = profile_id
		_update_player_name()
		_save_data()
		overlay = "profile"
		_refresh_ui()
	, Color("#287660"))


func _select_profile(profile_id: String) -> void:
	active_profile_id = profile_id
	_update_player_name()
	_save_data()
	_open_overlay("profile")


func _delete_profile(profile_id: String) -> void:
	var remaining_profiles: Array[Dictionary] = []
	for profile in profiles:
		if str(profile.get("id", "")) != profile_id:
			remaining_profiles.append(profile)
	profiles = remaining_profiles
	if active_profile_id == profile_id:
		active_profile_id = ""
	_update_player_name()
	_save_data()
	_open_overlay("profile")


func _toggle_music() -> void:
	music_enabled = not music_enabled
	_save_data()
	if music_enabled:
		music_context = ""
		_sync_audio_context()
	else:
		music_player.stop()
	_open_overlay("options")


func _toggle_sfx() -> void:
	sfx_enabled = not sfx_enabled
	_save_data()
	if sfx_enabled:
		_play_sfx("click")
	_open_overlay("options")


func _set_difficulty(value: String) -> void:
	difficulty = value
	_save_data()
	_open_overlay("options")


func _close_overlay() -> void:
	overlay = ""
	_refresh_ui()


func _add_label(parent: Control, text_value: String, font_size: int, color: Color) -> Label:
	return ui_style.add_label(parent, text_value, font_size, color)


func _add_button(parent: Control, text_value: String, callback: Callable, color: Color, height: float = 44.0) -> Button:
	var button: Button = ui_style.add_button(parent, text_value, callback, color, height, building_popup)
	button.button_down.connect(func() -> void: _play_sfx("click"))
	return button


func _button_style(color: Color) -> StyleBoxFlat:
	return ui_style.button_style(color)


func _apply_panel_style(control: Control, color: Color, border: Color) -> void:
	ui_style.apply_panel_style(control, color, border)


func _draw() -> void:
	match mode:
		"home":
			_draw_home_world()
		"crossing", "crossing_reward":
			_draw_crossing_world()
		"chase", "result":
			_draw_runner_world()
		"celebration":
			_draw_school_arrival()
		"jaywalk_catch":
			_draw_jaywalk_catch()


func _draw_city_backdrop() -> void:
	draw_rect(Rect2(0, 0, 960, 540), Color("#8d7863"))
	draw_rect(Rect2(0, 0, 960, 83), Color("#b9aa8d"))
	draw_rect(Rect2(0, 459, 960, 81), Color("#b9aa8d"))
	for index in range(12):
		var x := float(index * 86 - 14)
		var building_width := 74.0 + float((index * 11) % 19)
		var wall := Color("#d7b987") if index % 3 == 0 else Color("#c9916d") if index % 3 == 1 else Color("#a9b6a0")
		draw_rect(Rect2(x, 0, building_width, 83), Color("#685951"))
		draw_rect(Rect2(x + 4, 3, building_width - 8, 75), wall)
		draw_rect(Rect2(x + 4, 3, building_width - 8, 7), Color("#f1dfb9"))
		draw_rect(Rect2(x + 6, 67, building_width - 12, 10), Color("#725849"))
		for window_x in range(10, int(building_width) - 11, 20):
			draw_rect(Rect2(x + window_x, 17, 12, 18), Color("#496e79"))
			draw_rect(Rect2(x + window_x + 2, 19, 8, 3), Color("#d8c99e"))
			draw_rect(Rect2(x + window_x, 42, 12, 16), Color("#986847"))
		draw_rect(Rect2(x + 2, 77, building_width - 4, 6), Color("#514b45"))

	for seam_x in range(34, 960, 108):
		draw_rect(Rect2(seam_x, 469, 2, 63), Color("#a39884"))
	for seam_y in [483, 518]:
		draw_rect(Rect2(0, seam_y, 960, 2), Color("#c8b99b"))
	draw_rect(Rect2(70, 500, 19, 3), Color("#9b907e"))
	draw_rect(Rect2(710, 478, 14, 3), Color("#9b907e"))
	draw_rect(Rect2(854, 524, 24, 3), Color("#9b907e"))


func _draw_home_world() -> void:
	if intro_active:
		_draw_intro_background()
		_draw_intro_animation()
		return

	draw_rect(Rect2(0, 0, 960, 540), Color("#098ff0"))
	draw_rect(Rect2(0, 125, 960, 215), Color("#32a9ef"))
	draw_circle(Vector2(806, 99), 39, Color("#ffdc68"))

	_draw_pixel_cloud(Vector2(18, 45), 1.08)
	_draw_pixel_cloud(Vector2(548, 57), 0.72)
	_draw_pixel_cloud(Vector2(817, 66), 0.95)

	for index in range(18):
		var x := float(index * 57 - 22)
		var building_height := 45.0 + float((index * 37) % 72)
		var y := 343.0 - building_height
		var wall := Color("#eed397") if index % 3 == 0 else Color("#efc27e") if index % 2 == 0 else Color("#a8d6ed")
		draw_rect(Rect2(x, y, 53, building_height), Color("#668ba8"))
		draw_rect(Rect2(x + 2, y - 3, 49, building_height), wall)
		draw_rect(Rect2(x + 2, y + 5, 49, 5), Color("#fff0c8"))
		for window_row in range(2):
			for window_column in range(3):
				draw_rect(Rect2(x + 7 + window_column * 14, y + 15 + window_row * 18, 7, 10), Color("#55a5d1"))
				draw_rect(Rect2(x + 7 + window_column * 14, y + 14 + window_row * 18, 7, 2), Color("#fff3d3"))

	for index in range(31):
		var x := float(index * 35 - 16)
		var tree_y := 317.0 + float((index * 13) % 24)
		draw_rect(Rect2(x + 14, tree_y + 32, 7, 43), Color("#774934"))
		draw_rect(Rect2(x, tree_y + 13, 35, 35), Color("#1d9754"))
		draw_rect(Rect2(x + 5, tree_y + 3, 24, 31), Color("#39b75d"))
		draw_rect(Rect2(x + 12, tree_y - 3, 12, 20), Color("#59cc64"))

	draw_rect(Rect2(41, 171, 8, 193), Color("#55506b"))
	draw_rect(Rect2(27, 176, 38, 8), Color("#484761"))
	draw_rect(Rect2(42, 198, 214, 3), Color("#253b72"))
	draw_rect(Rect2(42, 212, 220, 3), Color("#253b72"))
	for wire_x in range(43, 249, 26):
		draw_rect(Rect2(wire_x, 198, 2, 12), Color("#314d82"))

	draw_rect(Rect2(0, 371, 960, 78), Color("#b9aa8d"))
	draw_rect(Rect2(0, 374, 960, 8), Color("#e8d5ad"))
	for x in range(-10, 980, 55):
		draw_rect(Rect2(x, 385, 31, 8), Color("#f0ddba"))
	draw_rect(Rect2(0, 449, 960, 91), Color("#33465c"))
	draw_rect(Rect2(0, 453, 960, 7), Color("#f3e3c6"))
	for x in range(-20, 1000, 142):
		draw_rect(Rect2(x, 498, 72, 7), Color("#f4e8cf"))

	_draw_bus_stop(Vector2(0, 294))
	_draw_pixel_jeepney(Vector2(211, 252), 659, 270)
	_draw_city_sign(Vector2(818, 231))
	_draw_student(Vector2(151, 349), world_time, true)
	_draw_pixel_wordmark(_home_logo_position())
	if home_reveal > 0.0:
		draw_rect(Rect2(0, 0, 960, 540), Color(0, 0, 0, home_reveal))


func _draw_intro_background() -> void:
	draw_rect(Rect2(0, 0, 960, 540), Color("#0b86d8"))
	draw_rect(Rect2(0, 0, 960, 246), Color("#32a9e9"))
	_draw_pixel_cloud(Vector2(-21, 54), 1.10)
	_draw_pixel_cloud(Vector2(438, 34), 0.75)
	_draw_pixel_cloud(Vector2(803, 65), 0.96)

	for index in range(20):
		var x := float(index * 51 - 15)
		var building_height := 48.0 + float((index * 29) % 75)
		var y := 336.0 - building_height
		var wall := Color("#b4c7ca") if index % 3 == 0 else Color("#e8cb97") if index % 2 == 0 else Color("#c5d6c8")
		draw_rect(Rect2(x, y, 48, building_height), Color("#507d9d"))
		draw_rect(Rect2(x + 2, y - 4, 44, building_height), wall)
		draw_rect(Rect2(x + 4, y + 5, 37, 5), Color("#fff0c8"))
		for row in range(2):
			for column in range(2):
				draw_rect(Rect2(x + 8 + column * 18, y + 17 + row * 20, 9, 11), Color("#438ab4"))
	draw_rect(Rect2(0, 290, 960, 91), Color("#29745a"))
	for index in range(33):
		var x := float(index * 31 - 11)
		var canopy_y := 290.0 + float((index * 17) % 34)
		draw_rect(Rect2(x + 12, canopy_y + 37, 7, 31), Color("#78533c"))
		draw_rect(Rect2(x, canopy_y + 14, 33, 34), Color("#188455"))
		draw_rect(Rect2(x + 5, canopy_y + 5, 24, 31), Color("#28a05c"))
		draw_rect(Rect2(x + 11, canopy_y, 12, 19), Color("#48ba62"))

	draw_rect(Rect2(0, 374, 960, 72), Color("#bcb196"))
	draw_rect(Rect2(0, 374, 960, 8), Color("#f0dfc2"))
	for x in range(0, 980, 30):
		draw_rect(Rect2(x, 333, 5, 45), Color("#d8ddd4"))
		draw_rect(Rect2(x, 341, 28, 5), Color("#d8ddd4"))
		draw_rect(Rect2(x, 359, 28, 5), Color("#d8ddd4"))
	draw_rect(Rect2(0, 385, 960, 5), Color("#d86660"))
	draw_rect(Rect2(0, 367, 960, 5), Color("#d86660"))

	draw_rect(Rect2(0, INTRO_ROAD_TOP, 960, VIEW_SIZE.y - INTRO_ROAD_TOP), Color("#34485e"))
	draw_rect(Rect2(0, INTRO_ROAD_TOP, 960, 8), Color("#f4e8d0"))
	for x in range(-20, 1000, 145):
		draw_rect(Rect2(x, 514, 78, 7), Color("#f5e9d2"))

	draw_rect(Rect2(820, 255, 124, 54), Color("#102a52"))
	draw_rect(Rect2(825, 260, 114, 44), Color("#17627b"))
	_draw_centered_text("CEBU CITY", 882.0, 288.0, 11, Color("#fff4d1"))
	draw_rect(Rect2(831, 309, 5, 64), Color("#4a4654"))
	draw_rect(Rect2(929, 309, 5, 64), Color("#4a4654"))


func _intro_runner_position(elapsed: float) -> Vector2:
	var run_time := maxf(0.0, elapsed - INTRO_RUNNER_START)
	var initial_entry := clampf(run_time, 0.0, 1.0)
	var x := lerpf(-82.0, 94.0, _ease_out_cubic(initial_entry))
	if run_time > 1.0:
		x += minf(run_time - 1.0, 4.0) * 161.0
	return Vector2(x, INTRO_GROUND_Y)


func _intro_officer_position(elapsed: float) -> Vector2:
	var student_position := _intro_runner_position(elapsed)
	var officer_entry := clampf(elapsed - INTRO_OFFICER_START, 0.0, 1.0)
	var x := lerpf(-88.0, student_position.x - 128.0, _ease_out_cubic(officer_entry))
	if elapsed > INTRO_OFFICER_START + 1.0:
		x = student_position.x - 128.0 + sin(elapsed * 5.5) * 8.0
	return Vector2(x, INTRO_GROUND_Y - 83.0 * INTRO_OFFICER_SCALE)


func _intro_jeepney_position(elapsed: float) -> Vector2:
	var officer_position := _intro_officer_position(elapsed)
	var bob := sin(elapsed * 9.0) * 2.0
	return Vector2(
		officer_position.x - INTRO_JEEPNEY_SIZE.x - INTRO_JEEPNEY_CHASE_GAP + sin(elapsed * 7.0) * 2.0,
		INTRO_GROUND_Y - INTRO_JEEPNEY_SIZE.y + bob
	)


func _intro_character_texture() -> Texture2D:
	return GIRL_TEXTURE if selected_character == "girl" else BOY_TEXTURE


func _draw_intro_runner(position: Vector2, animation_time: float, texture: Texture2D, color: Color) -> void:
	var bob_frames := [0.0, -2.0, -4.0, -1.0]
	var frame: int = int(animation_time * 12.0) % bob_frames.size()
	var bob: float = bob_frames[frame]
	var sprite_size := INTRO_CHARACTER_SIZE
	var sprite_rect := Rect2(
		Vector2(position.x - sprite_size.x * 0.5, position.y - sprite_size.y + bob),
		sprite_size
	)
	draw_rect(Rect2(position.x - 26, position.y - 3, 52, 5), Color(0.08, 0.13, 0.17, 0.45))
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	draw_texture_rect(texture, sprite_rect, false, color)


func _draw_intro_animation() -> void:
	var elapsed := intro_elapsed

	if elapsed >= INTRO_RUNNER_START:
		var student_position := _intro_runner_position(elapsed)

		if elapsed >= INTRO_OFFICER_START:
			var officer_position := _intro_officer_position(elapsed)
			var jeepney_position := _intro_jeepney_position(elapsed)
			_draw_intro_jeepney(jeepney_position)
			_draw_officer(officer_position, world_time, true, INTRO_OFFICER_SCALE)

		_draw_intro_runner(student_position, world_time, _intro_character_texture(), Color.WHITE)

	if elapsed >= INTRO_LOGO_START:
		var logo_transform := _intro_logo_transform(elapsed)
		var logo_position: Vector2 = logo_transform["position"]
		var logo_scale: float = logo_transform["scale"]
		_draw_pixel_wordmark(logo_position, logo_scale)
		_draw_logo_impact(logo_position, logo_scale, float(logo_transform["impact"]))

	var fade_alpha := 0.0
	if elapsed >= INTRO_FADE_OUT_START:
		fade_alpha = clampf((elapsed - INTRO_FADE_OUT_START) / INTRO_FADE_OUT_DURATION, 0.0, 1.0)
	if fade_alpha > 0.0:
		draw_rect(Rect2(0, 0, VIEW_SIZE.x, VIEW_SIZE.y), Color(0, 0, 0, fade_alpha))


func _ease_out_cubic(progress: float) -> float:
	return 1.0 - pow(1.0 - progress, 3.0)


func _home_logo_position() -> Vector2:
	var idle_bob := sin(world_time * 1.7) * 1.5
	return Vector2((VIEW_SIZE.x - WORDMARK_SIZE.x) * 0.5, WORDMARK_HOME_Y + idle_bob)


func _intro_logo_transform(elapsed: float) -> Dictionary:
	var progress := clampf((elapsed - INTRO_LOGO_START) / INTRO_LOGO_SLIDE_DURATION, 0.0, 1.0)
	var eased_progress := _ease_out_cubic(progress)
	var centered_x := (VIEW_SIZE.x - WORDMARK_SIZE.x) * 0.5
	var impact_progress := clampf(
		(elapsed - INTRO_LOGO_START - INTRO_LOGO_SLIDE_DURATION) / INTRO_LOGO_IMPACT_DURATION,
		0.0,
		1.0
	)
	var impact_bounce := -sin(impact_progress * PI) * 4.0
	return {
		"position": Vector2(
			lerpf(centered_x + 150.0, centered_x, eased_progress),
			WORDMARK_HOME_Y + lerpf(10.0, 0.0, eased_progress) + impact_bounce
		),
		"scale": lerpf(0.82, 1.0, eased_progress),
		"impact": 1.0 - impact_progress if elapsed >= INTRO_LOGO_START + INTRO_LOGO_SLIDE_DURATION else 0.0,
	}


func _draw_logo_impact(position: Vector2, scale: float, strength: float) -> void:
	if strength <= 0.0:
		return
	var left := position.x - 7.0 * scale
	var right := position.x + WORDMARK_SIZE.x * scale + 2.0 * scale
	var center_y := position.y + 50.0 * scale
	var bright := Color("#ffd94a")
	bright.a = strength
	var shadow := Color("#172238")
	shadow.a = strength
	for line in [
		[Vector2(left - 9.0, center_y - 11.0), Vector2(7.0, 2.0)],
		[Vector2(left - 5.0, center_y + 12.0), Vector2(5.0, 2.0)],
		[Vector2(right + 3.0, center_y - 7.0), Vector2(8.0, 2.0)],
		[Vector2(right + 1.0, center_y + 15.0), Vector2(6.0, 2.0)],
	]:
		draw_rect(
			Rect2(line[0], line[1] * scale),
			shadow.lightened(0.12),
			true
		)
	draw_rect(Rect2(left - 1.0, center_y - 10.0, 5.0 * scale, 2.0 * scale), bright)
	draw_rect(Rect2(right + 4.0 * scale, center_y + 7.0 * scale, 6.0 * scale, 2.0 * scale), bright)


func _draw_pixel_wordmark(position: Vector2, scale: float = 1.0) -> void:
	var glyphs := {
		"R": ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
		"O": ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
		"A": ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
		"D": ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
		"U": ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
		"S": ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
		"H": ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
	}
	var cell_size := 13.0 * scale
	var pitch := 15.0 * scale

	var pixels: Array[Vector2i] = []
	var pixel_lookup := {}
	var glyph_column := 0
	for character in "ROAD RUSH":
		if character == " ":
			glyph_column += 3
			continue
		var pattern: Array = glyphs[character]
		for row in range(pattern.size()):
			for column in range(5):
				if pattern[row].substr(column, 1) != "1":
					continue
				var pixel := Vector2i(glyph_column + column, row)
				pixels.append(pixel)
				pixel_lookup[pixel] = true
		glyph_column += 6

	for pixel in pixels:
		var cell := position + Vector2(pixel) * pitch
		draw_rect(
			Rect2(cell + Vector2(5, 8) * scale, Vector2(cell_size + 2, cell_size + 2)),
			Color("#172238")
		)

	for pixel in pixels:
		var cell := position + Vector2(pixel) * pitch
		for neighbor_y in range(-1, 2):
			for neighbor_x in range(-1, 2):
				var neighbor_grid := pixel + Vector2i(neighbor_x, neighbor_y)
				if not pixel_lookup.has(neighbor_grid):
					var neighbor := position + Vector2(neighbor_grid) * pitch
					draw_rect(
						Rect2(neighbor - Vector2(1.0, 1.0) * scale, Vector2(cell_size + 2, cell_size + 2)),
						Color("#2a2030")
					)

	for pixel in pixels:
		var cell := position + Vector2(pixel) * pitch
		var face_color := Color("#ef493d")
		if pixel.y == 0:
			face_color = Color("#ffd94a")
		elif pixel.y == 1:
			face_color = Color("#ff9c2d")
		elif pixel.y >= 6:
			face_color = Color("#c9363e")
		draw_rect(Rect2(cell, Vector2(cell_size, cell_size)), face_color)
		draw_rect(
			Rect2(cell + Vector2(0, 8) * scale, Vector2(cell_size, 2 * scale)),
			Color("#ff7042") if pixel.y >= 2 and pixel.y < 6 else face_color
		)
		if pixel.y == 0 and pixel.x % 2 == 0:
			draw_rect(Rect2(cell + Vector2(2, 1) * scale, Vector2(8, 2) * scale), Color("#fff2a1"))

	var center_y := position.y + 53.0 * scale
	for side in [-1.0, 1.0]:
		var speed_line_x := position.x - 13.0 * scale if side < 0.0 else position.x + (WORDMARK_SIZE.x + 5.0) * scale
		for line_index in range(3):
			var line_y := center_y + float(line_index - 1) * 9.0 * scale
			var line_width := float(13 - line_index * 3) * scale
			var line_x := speed_line_x - line_width if side < 0.0 else speed_line_x
			draw_rect(Rect2(line_x, line_y, line_width, 2.0 * scale), Color("#ffc34a"))
func _draw_pixel_cloud(position: Vector2, scale: float) -> void:
	var white := Color("#f8ffff")
	var blue_white := Color("#d8f4ff")
	draw_rect(Rect2(position + Vector2(0, 24) * scale, Vector2(128, 25) * scale), blue_white)
	draw_rect(Rect2(position + Vector2(20, 12) * scale, Vector2(38, 37) * scale), white)
	draw_rect(Rect2(position + Vector2(49, 0) * scale, Vector2(43, 51) * scale), white)
	draw_rect(Rect2(position + Vector2(81, 9) * scale, Vector2(32, 38) * scale), white)
	draw_rect(Rect2(position + Vector2(107, 20) * scale, Vector2(33, 27) * scale), blue_white)
	draw_rect(Rect2(position + Vector2(8, 36) * scale, Vector2(126, 9) * scale), blue_white)


func _draw_bus_stop(position: Vector2) -> void:
	draw_rect(Rect2(position + Vector2(0, 66), Vector2(91, 8)), Color("#514159"))
	draw_rect(Rect2(position + Vector2(5, 0), Vector2(7, 76)), Color("#46475d"))
	draw_rect(Rect2(position + Vector2(78, 12), Vector2(7, 64)), Color("#46475d"))
	draw_rect(Rect2(position + Vector2(0, 11), Vector2(93, 42)), Color("#ffd344"))
	draw_rect(Rect2(position + Vector2(5, 16), Vector2(82, 30)), Color("#f64b49"))
	draw_rect(Rect2(position + Vector2(20, 53), Vector2(4, 31)), Color("#444357"))
	draw_rect(Rect2(position + Vector2(68, 53), Vector2(4, 31)), Color("#444357"))


func _draw_city_sign(position: Vector2) -> void:
	draw_rect(Rect2(position + Vector2(-4, 25), Vector2(13, 66)), Color("#50465a"))
	draw_rect(Rect2(position + Vector2(109, 25), Vector2(13, 66)), Color("#50465a"))
	draw_rect(Rect2(position, Vector2(122, 53)), Color("#102a52"))
	draw_rect(Rect2(position + Vector2(5, 5), Vector2(112, 43)), Color("#147aa1"))
	draw_rect(Rect2(position + Vector2(9, 9), Vector2(104, 35)), Color("#195878"))
	_draw_centered_text("CEBU CITY", position.x + 61.0, position.y + 32.0, 12, Color("#ffffff"))


func _draw_intro_jeepney(position: Vector2) -> void:
	var width := INTRO_JEEPNEY_SIZE.x
	var ground_y := position.y + INTRO_JEEPNEY_SIZE.y
	var frame := int(floor(world_time * 12.0)) % 2
	draw_rect(Rect2(position + Vector2(24, 181), Vector2(288, 9)), Color(0.08, 0.13, 0.17, 0.38))

	for wheel_x in [position.x + 57.0, position.x + 255.0]:
		draw_rect(Rect2(wheel_x, ground_y - 44.0, 52.0, 44.0), Color("#14243b"))
		draw_rect(Rect2(wheel_x + 8.0, ground_y - 36.0, 36.0, 28.0), Color("#62717a"))
		draw_rect(Rect2(wheel_x + 18.0, ground_y - 31.0, 16.0, 18.0), Color("#e4bd4b"))
		draw_rect(Rect2(wheel_x + 22.0 + frame * 4, ground_y - 36.0, 5.0, 28.0), Color("#243c50"))

	draw_rect(Rect2(position + Vector2(14, 53), Vector2(312, 119)), Color("#132949"))
	draw_rect(Rect2(position + Vector2(20, 59), Vector2(300, 105)), Color("#0877c9"))
	draw_rect(Rect2(position + Vector2(34, 25), Vector2(272, 51)), Color("#142b4c"))
	draw_rect(Rect2(position + Vector2(41, 18), Vector2(258, 49)), Color("#e3483b"))
	draw_rect(Rect2(position + Vector2(52, 26), Vector2(236, 9)), Color("#ffd34b"))
	draw_rect(Rect2(position + Vector2(57, 39), Vector2(226, 17)), Color("#ff6240"))
	draw_rect(Rect2(position + Vector2(45, 65), Vector2(250, 68)), Color("#103453"))

	for window_x in [55.0, 105.0, 155.0, 205.0, 255.0]:
		draw_rect(Rect2(position + Vector2(window_x, 70), Vector2(42, 53)), Color("#17496b"))
		draw_rect(Rect2(position + Vector2(window_x + 5, 75), Vector2(32, 40)), Color("#8de0e9"))
		draw_rect(Rect2(position + Vector2(window_x + 8, 78), Vector2(7, 7)), Color("#d8fbf3"))

	draw_rect(Rect2(position + Vector2(22, 132), Vector2(296, 11)), Color("#ffe06a"))
	draw_rect(Rect2(position + Vector2(20, 147), Vector2(300, 8)), Color("#f4e8cf"))
	draw_rect(Rect2(position + Vector2(18, 159), Vector2(304, 9)), Color("#d83c3b"))
	draw_rect(Rect2(position + Vector2(3, 111), Vector2(18, 17)), Color("#ffcf42"))
	draw_rect(Rect2(position + Vector2(width - 21, 111), Vector2(18, 17)), Color("#ffcf42"))
	draw_rect(Rect2(position + Vector2(27, 178), Vector2(286, 5)), Color("#dce7ec"))
	_draw_centered_text("CEBU CITY", position.x + width * 0.5, position.y + 155.0, 14, Color("#173958"))

	var exhaust_phase := fposmod(world_time * 4.0, 1.0)
	var exhaust_alpha := 0.48 * (1.0 - exhaust_phase)
	draw_rect(
		Rect2(position.x - 8.0 - exhaust_phase * 30.0, ground_y - 48.0 - exhaust_phase * 26.0, 18, 12),
		Color(0.77, 0.86, 0.83, exhaust_alpha)
	)
	draw_rect(
		Rect2(position.x - 26.0 - exhaust_phase * 28.0, ground_y - 40.0 - exhaust_phase * 35.0, 11, 8),
		Color(0.77, 0.86, 0.83, exhaust_alpha * 0.72)
	)


func _draw_pixel_jeepney(position: Vector2, width: float, height: float) -> void:
	var navy := Color("#101e45")
	var body := Color("#0575ed")
	var red := Color("#ef393b")
	var yellow := Color("#ffd329")
	var cream := Color("#fff2b8")

	for wheel_x in [position.x + 133.0, position.x + width - 144.0]:
		draw_circle(Vector2(wheel_x, position.y + height - 12), 52, navy)
		draw_circle(Vector2(wheel_x, position.y + height - 12), 38, Color("#415b88"))
		draw_circle(Vector2(wheel_x, position.y + height - 12), 28, Color("#d9e9eb"))
		draw_circle(Vector2(wheel_x, position.y + height - 12), 15, Color("#ffb51f"))
		draw_rect(Rect2(wheel_x - 4, position.y + height - 31, 8, 38), cream)

	draw_rect(Rect2(position.x + 35, position.y + 68, width - 70, height - 92), navy)
	draw_rect(Rect2(position.x + 47, position.y + 58, width - 93, height - 101), body)
	draw_rect(Rect2(position.x + 53, position.y + 29, width - 105, 70), red)
	draw_rect(Rect2(position.x + 69, position.y + 38, width - 137, 42), Color("#ff6240"))
	draw_rect(Rect2(position.x + 65, position.y + 83, width - 129, 8), yellow)
	draw_rect(Rect2(position.x + 48, position.y + 101, width - 97, 8), Color("#fff0ac"))
	draw_rect(Rect2(position.x + 57, position.y + 120, width - 115, height - 188), navy)

	var windows_start := position.x + 77.0
	var window_y := position.y + 133.0
	var window_width := (width - 196.0) / 5.0
	for window_index in range(5):
		var window_x := windows_start + window_index * (window_width + 8)
		draw_rect(Rect2(window_x - 3, window_y - 3, window_width + 6, 62), navy)
		draw_rect(Rect2(window_x, window_y, window_width, 54), Color("#75d9f1"))
		draw_rect(Rect2(window_x + 3, window_y + 4, window_width - 6, 6), Color("#b9f1ff"))
		draw_rect(Rect2(window_x + window_width - 5, window_y, 5, 54), Color("#eaf7dc"))

	draw_rect(Rect2(position.x + 44, position.y + 111, width - 87, 11), red)
	draw_rect(Rect2(position.x + 56, position.y + 116, width - 111, 6), yellow)
	draw_rect(Rect2(position.x + 56, position.y + height - 53, width - 112, 14), navy)
	draw_rect(Rect2(position.x + 65, position.y + height - 48, width - 130, 5), yellow)
	draw_rect(Rect2(position.x + 37, position.y + height - 42, width - 75, 18), Color("#dce7ec"))
	draw_rect(Rect2(position.x + 43, position.y + height - 39, width - 88, 6), Color("#ffffff"))
	draw_rect(Rect2(position.x + 43, position.y + 99, 15, 42), yellow)
	draw_rect(Rect2(position.x + width - 59, position.y + 99, 15, 42), yellow)
	draw_rect(Rect2(position.x + 39, position.y + 145, 15, 37), red)
	draw_rect(Rect2(position.x + width - 54, position.y + 145, 15, 37), red)
	draw_rect(Rect2(position.x + width - 98, position.y + height - 123, 39, 29), cream)
	draw_rect(Rect2(position.x + width - 92, position.y + height - 119, 24, 16), Color("#ffb423"))
	draw_rect(Rect2(position.x + 12, position.y + 202, width - 24, 15), Color("#102b51"))
	_draw_text("CEBU  •  01B", position + Vector2(width / 2, 213), 10, Color("#fff4ca"), HORIZONTAL_ALIGNMENT_CENTER)


func _draw_crossing_world() -> void:
	_draw_city_backdrop()
	draw_rect(Rect2(0, 83, 960, 34), Color("#b9aa8d"))
	draw_rect(Rect2(0, 420, 960, 39), Color("#b9aa8d"))
	draw_rect(Rect2(0, 111, 960, 314), Color("#3e4547"))
	draw_rect(Rect2(0, 111, 960, 7), Color("#d0c5ac"))
	draw_rect(Rect2(0, 420, 960, 7), Color("#d0c5ac"))
	draw_rect(Rect2(0, 274, 960, 34), Color("#8b814d"))
	draw_rect(Rect2(0, 287, 960, 4), Color("#6d663f"))
	for y in [158, 224, 356, 402]:
		for x in range(0, 960, 78):
			draw_rect(Rect2(x, y, 42, 3), Color(0.92, 0.9, 0.82, 0.28))
	for stripe_index in range(CROSSWALK_PAINT_STRIPES.size()):
		var stripe: Vector2 = CROSSWALK_PAINT_STRIPES[stripe_index]
		var stripe_x := CROSSWALK_LEFT + stripe.x
		var stripe_y := 119.0 + stripe_index * 40.0
		var block_count := int(stripe.y / CROSSWALK_PAINT_BLOCK_SIZE)
		for block_index in range(block_count):
			if (block_index + stripe_index) % 5 == 3:
				continue
			var block_x := stripe_x + block_index * CROSSWALK_PAINT_BLOCK_SIZE
			var paint_alpha := 0.42 if (block_index + stripe_index) % 3 == 0 else 0.58
			draw_rect(Rect2(block_x, stripe_y, 10, 13), Color("#e1ddcf", paint_alpha))
			if (block_index + stripe_index) % 4 == 1:
				draw_rect(Rect2(block_x + 3, stripe_y + 2, 4, 9), Color("#a9a69d", 0.58))
	_draw_broken_crossing_signal()
	for car in crossing_cars:
		_draw_crossing_vehicle(car)
	for coin in crossing_coins:
		_draw_crossing_coin(coin)
	_draw_student(Vector2(player_x, player_y), world_time, false)
	if crossing_hit_timer > 0.0:
		draw_rect(CROSSING_HIT_RECT, Color("#a64035"))
		_draw_bold_centered_text(
			"WATCH THE TRAFFIC!",
			CROSSING_HIT_RECT.get_center().x,
			CROSSING_HIT_RECT.position.y + 27.0,
			12,
			Color("#fff1d1")
		)


func _draw_school_arrival() -> void:
	var elapsed := minf(celebration_elapsed, ARRIVAL_CELEBRATION_DURATION)
	var progress := clampf(elapsed / 2.7, 0.0, 1.0)
	var student_position := _arrival_student_position(elapsed)
	var student_x := student_position.x
	var student_ground_y := student_position.y
	var student_scale := _arrival_student_scale(elapsed)
	var walk_bob := sin(elapsed * 12.0) * 3.0 if progress < 1.0 else 0.0
	var arrival_message := _arrival_message()

	draw_rect(Rect2(0, 0, 960, 315), Color("#86c8d1"))
	draw_rect(Rect2(88, 63, 126, 14), Color("#f6edd3"))
	draw_rect(Rect2(67, 70, 171, 13), Color("#f6edd3"))
	_draw_arrival_city_building(Rect2(18, 160, 126, 150), Color("#806f6a"), Color("#e9c97c"))
	_draw_arrival_city_building(Rect2(164, 204, 112, 106), Color("#9b7867"), Color("#c7ddd0"))
	_draw_arrival_city_building(Rect2(296, 176, 142, 134), Color("#6c7775"), Color("#e5c67a"))
	_draw_arrival_city_building(Rect2(879, 187, 70, 123), Color("#747b70"), Color("#e9c97c"))
	draw_rect(Rect2(0, 300, 960, 240), Color("#71945d"))

	draw_rect(Rect2(367, 115, 546, 278), Color("#455568"))
	draw_rect(Rect2(376, 105, 528, 280), Color("#d8c7a0"))
	draw_rect(Rect2(389, 119, 502, 18), Color("#f2e5c4"))
	draw_rect(Rect2(389, 137, 502, 7), Color("#92734f"))
	draw_rect(Rect2(398, 144, 478, 223), Color("#c8b287"))
	for floor_y in [216, 288]:
		draw_rect(Rect2(397, floor_y, 480, 9), Color("#f0dfb7"))
		draw_rect(Rect2(397, floor_y + 9, 480, 5), Color("#806e56"))
	for floor_y in [158, 230, 302]:
		for window_x in range(414, 866, 54):
			draw_rect(Rect2(window_x - 3, floor_y - 3, 40, 43), Color("#52616a"))
			draw_rect(Rect2(window_x, floor_y, 34, 35), Color("#82c5cd"))
			draw_rect(Rect2(window_x + 4, floor_y + 4, 26, 6), Color("#c5e5dc"))
			draw_rect(Rect2(window_x + 15, floor_y, 4, 35), Color("#e8d7ad"))
	draw_rect(Rect2(566, 80, 148, 25), Color("#8b6a48"))
	draw_rect(Rect2(573, 84, 134, 17), Color("#f0dfb7"))
	_draw_bold_centered_text("UV", 640.0, 98.0, 15, Color("#23485b"))
	draw_rect(Rect2(524, 119, 235, 36), Color("#23485b"))
	draw_rect(Rect2(530, 124, 223, 26), Color("#f2e5c4"))
	_draw_bold_centered_text("UNIVERSITY OF THE VISAYAS", 641.5, 143.0, 11, Color("#23485b"))

	draw_rect(Rect2(604, 267, 76, 119), Color("#334858"))
	draw_rect(Rect2(611, 274, 62, 112), Color("#704f38"))
	draw_rect(Rect2(619, 282, 46, 104), Color("#253c4a"))
	draw_rect(Rect2(623, 287, 38, 96), Color("#668e87"))
	draw_rect(Rect2(637, 288, 4, 94), Color("#e1ca97"))
	draw_rect(Rect2(652, 330, 4, 4), Color("#f4d36f"))
	draw_rect(Rect2(590, 257, 104, 11), Color("#f0dfb7"))
	draw_rect(Rect2(598, 268, 9, 117), Color("#f0dfb7"))
	draw_rect(Rect2(679, 268, 9, 117), Color("#f0dfb7"))
	draw_rect(Rect2(0, 393, 960, 147), Color("#c9ac76"))
	draw_rect(Rect2(0, 393, 960, 8), Color("#ead5a1"))
	draw_rect(Rect2(0, 408, 960, 132), Color("#b99c6a"))
	draw_colored_polygon(
		PackedVector2Array([Vector2(400, 393), Vector2(840, 393), Vector2(770, 540), Vector2(156, 540)]),
		Color("#d9c69a")
	)
	draw_rect(Rect2(0, 397, 960, 7), Color("#73915e"))

	var confetti_colors: Array[Color] = [Color("#e84c45"), Color("#f4c844"), Color("#3b9e73"), Color("#478ac4")]
	for confetti_index in range(22):
		var seed := float(confetti_index)
		var confetti_x := fposmod(seed * 137.0 + sin(elapsed * 1.8 + seed) * 24.0, 960.0)
		var confetti_y := fposmod(seed * 31.0 + elapsed * (52.0 + fposmod(seed, 4.0) * 12.0), 315.0)
		var confetti_color: Color = confetti_colors[confetti_index % confetti_colors.size()]
		draw_rect(Rect2(confetti_x, confetti_y, 7, 9), confetti_color)
		draw_rect(Rect2(confetti_x + 2, confetti_y + 2, 3, 3), Color("#fff1cf"))

	var student_sprite_size := Vector2(120, 120) * student_scale
	var student_rect := Rect2(
		student_x - student_sprite_size.x * 0.5,
		student_ground_y - student_sprite_size.y + walk_bob * student_scale,
		student_sprite_size.x,
		student_sprite_size.y
	)
	draw_rect(
		Rect2(student_x - 30.0 * student_scale, student_ground_y + 3.0, 60.0 * student_scale, 8.0 * student_scale),
		Color(0.08, 0.13, 0.17, 0.25)
	)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	draw_texture_rect(_intro_character_texture(), student_rect, false)

	draw_rect(Rect2(214, 31, 532, 83), Color("#18334a"))
	draw_rect(Rect2(221, 38, 518, 69), Color("#f4c84b"))
	_draw_bold_centered_text("CONGRATULATIONS!", 480.0, 70.0, 24, Color("#b43e3d"))
	_draw_bold_centered_text(arrival_message, 480.0, 94.0, 15, Color("#23485b"))
	if elapsed > 3.0:
		draw_rect(Rect2(382, 474, 196, 34), Color("#1e604f"))
		_draw_bold_centered_text("UV CAMPUS!", 480.0, 497.0, 13, Color("#fff1cb"))


func _arrival_student_position(elapsed: float) -> Vector2:
	var progress := clampf(elapsed / 2.7, 0.0, 1.0)
	var eased_progress := _ease_out_cubic(progress)
	return Vector2(lerpf(-70.0, 642.0, eased_progress), lerpf(397.0, 385.0, eased_progress))


func _arrival_student_scale(elapsed: float) -> float:
	var progress := clampf(elapsed / 2.7, 0.0, 1.0)
	return lerpf(1.0, 0.52, _ease_out_cubic(progress))


func _draw_jaywalk_catch() -> void:
	var elapsed := minf(jaywalk_catch_elapsed, JAYWALK_CATCH_DURATION)
	var officer_progress := clampf(elapsed / 1.9, 0.0, 1.0)
	var officer_x := lerpf(-82.0, 430.0, _ease_out_cubic(officer_progress))
	var student_x := 486.0 + minf(elapsed, 1.9) * 7.0
	var officer_scale := 1.18
	var ground_y := 453.0

	_draw_city_backdrop()
	draw_rect(Rect2(0, 83, 960, 34), Color("#b9aa8d"))
	draw_rect(Rect2(0, 111, 960, 314), Color("#3e4547"))
	draw_rect(Rect2(0, 111, 960, 7), Color("#d0c5ac"))
	draw_rect(Rect2(0, 420, 960, 39), Color("#b9aa8d"))
	for stripe_y in [158, 224, 356, 402]:
		for stripe_x in range(0, 960, 78):
			draw_rect(Rect2(stripe_x, stripe_y, 42, 3), Color(0.92, 0.9, 0.82, 0.28))
	for stripe_index in range(CROSSWALK_PAINT_STRIPES.size()):
		var stripe: Vector2 = CROSSWALK_PAINT_STRIPES[stripe_index]
		var block_count := int(stripe.y / CROSSWALK_PAINT_BLOCK_SIZE)
		for block_index in range(block_count):
			if (block_index + stripe_index) % 5 != 3:
				draw_rect(
					Rect2(CROSSWALK_LEFT + stripe.x + block_index * CROSSWALK_PAINT_BLOCK_SIZE, 119.0 + stripe_index * 40.0, 10, 13),
					Color("#e1ddcf", 0.5)
				)

	draw_rect(Rect2(student_x - 31.0, ground_y - 5.0, 71, 10), Color(0.08, 0.13, 0.17, 0.3))
	draw_rect(Rect2(officer_x - 8.0, ground_y - 3.0, 73, 9), Color(0.08, 0.13, 0.17, 0.3))
	_draw_student(Vector2(student_x, ground_y - 63.0), world_time, false)
	_draw_officer(
		Vector2(officer_x, ground_y - 83.0 * officer_scale),
		world_time,
		officer_progress >= 0.86,
		officer_scale
	)

	draw_rect(Rect2(126, 39, 708, 78), Color("#18334a"))
	draw_rect(Rect2(134, 47, 692, 62), Color("#d84b3f"))
	_draw_bold_centered_text("OFFICER CAUGHT YOU JAYWALKING!", 480.0, 86.0, 19, Color("#fff1cb"))
	if elapsed >= 2.0:
		draw_rect(Rect2(397, 474, 166, 38), Color("#f4c84b"))
		_draw_bold_centered_text("RUN!  →", 480.0, 500.0, 18, Color("#18334a"))


func _draw_arrival_city_building(rect: Rect2, wall_color: Color, window_color: Color) -> void:
	draw_rect(rect, Color("#4e5d60"))
	draw_rect(rect.grow(-5.0), wall_color)
	draw_rect(Rect2(rect.position.x + 3.0, rect.position.y + 7.0, rect.size.x - 6.0, 6.0), Color("#d2ad70"))
	for window_y in range(int(rect.position.y + 22.0), int(rect.end.y - 12.0), 27):
		for window_x in range(int(rect.position.x + 12.0), int(rect.end.x - 9.0), 24):
			draw_rect(Rect2(window_x, window_y, 12, 15), Color("#4b656a"))
			draw_rect(Rect2(window_x + 2, window_y + 2, 8, 10), window_color)


func _draw_broken_crossing_signal() -> void:
	draw_rect(CROSSING_WARNING_RECT, Color("#312c3a"))
	draw_rect(CROSSING_WARNING_RECT.grow(-4), Color("#e5bd50"))
	_draw_centered_text("WARNING! THE TRAFFIC", CROSSING_WARNING_RECT.get_center().x, 437.0, 12, Color("#b32e31"))
	_draw_centered_text("LIGHT IS BROKEN.", CROSSING_WARNING_RECT.get_center().x, 454.0, 12, Color("#b32e31"))

	draw_rect(CROSSING_SIGNAL_RECT, Color("#3b3740"))
	draw_rect(CROSSING_SIGNAL_RECT.grow(-4), Color("#222b34"))
	var signal_red := _signal_is_red()
	var signal_yellow := _signal_is_yellow()
	var signal_green := _signal_is_green()
	draw_rect(Rect2(259, 428, 22, 22), Color("#cc4a3e") if signal_red else Color("#603a3a"))
	draw_rect(Rect2(299, 428, 22, 22), Color("#e1b548") if signal_yellow else Color("#625638"))
	draw_rect(Rect2(339, 428, 22, 22), Color("#46bb69") if signal_green else Color("#38583f"))
	draw_rect(Rect2(264, 432, 5, 5), Color("#ffaaa0") if signal_red else Color("#9a5551"))
	draw_rect(Rect2(304, 432, 5, 5), Color("#fff0a4") if signal_yellow else Color("#887b54"))
	draw_rect(Rect2(344, 432, 5, 5), Color("#b4f5a6") if signal_green else Color("#527458"))
	draw_rect(Rect2(267, 452, 7, 2), Color("#514b43"))
	draw_rect(Rect2(346, 452, 7, 2), Color("#514b43"))


func _draw_crossing_coin(coin: Dictionary) -> void:
	var coin_position := Vector2(float(coin["x"]), float(coin["y"]))
	var bob := sin(world_time * 6.0 + coin_position.y) * 2.0
	var position := coin_position + Vector2(0.0, bob)
	draw_rect(Rect2(position + Vector2(5, 0), Vector2(9, 18)), Color("#8f5826"))
	draw_rect(Rect2(position + Vector2(4, 0), Vector2(9, 16)), Color("#f1a82e"))
	draw_rect(Rect2(position + Vector2(6, 2), Vector2(5, 12)), Color("#ffdc5b"))
	draw_rect(Rect2(position + Vector2(7, 4), Vector2(3, 6)), Color("#fff0a4"))


func _draw_runner_world() -> void:
	draw_rect(Rect2(0, 0, 960, 540), Color("#cfc3a8"))
	for row in range(-1, 6):
		var y := float(row * 120) + fposmod(road_offset * 0.45, 120.0) - 120.0
		_draw_storefront(0, y, Color("#b77558") if row % 2 == 0 else Color("#8b9f8b"), "CARINDERIA" if row % 2 == 0 else "UKAY-UKAY")
		_draw_storefront(796, y - 45, Color("#d0a15d") if row % 2 == 0 else Color("#899ca0"), "CEBU TRADING" if row % 2 == 0 else "SARI-SARI")
	draw_rect(Rect2(164, 0, 26, 540), Color("#a69f90"))
	draw_rect(Rect2(770, 0, 26, 540), Color("#a69f90"))
	for y in range(-35, 590, 58):
		var sidewalk_y := float(y) + fposmod(road_offset, 58.0)
		draw_rect(Rect2(169, sidewalk_y, 14, 28), Color("#777266"))
		draw_rect(Rect2(777, sidewalk_y, 14, 28), Color("#777266"))
	draw_rect(Rect2(RUNNER_ROAD_LEFT, 0, RUNNER_ROAD_RIGHT - RUNNER_ROAD_LEFT, 540), Color("#4e5557"))
	draw_rect(Rect2(RUNNER_ROAD_LEFT, 0, 6, 540), Color("#ded5bd"))
	draw_rect(Rect2(RUNNER_ROAD_RIGHT - 6, 0, 6, 540), Color("#ded5bd"))
	for lane_x in [305, 420, 535, 650]:
		for y in range(-70, 610, 94):
			draw_rect(Rect2(lane_x, float(y) + fposmod(road_offset, 94.0), 5, 43), Color("#ddd5be"))
	draw_rect(Rect2(20, 18, 128, 41), Color("#2e6b67"))
	_draw_text("SANGTIANKO ST.", Vector2(84, 44), 10, Color("#fff5dd"), HORIZONTAL_ALIGNMENT_CENTER)

	for hazard in hazards:
		_draw_runner_vehicle(hazard)
	for coin in runner_coins:
		_draw_crossing_coin(coin)
	var officer_position := _runner_officer_position()
	_draw_officer(officer_position, world_time, runner_elapsed > 90.0, RUNNER_OFFICER_SCALE)
	_draw_student(Vector2(player_x, player_y), world_time, false)


func _draw_storefront(x: float, y: float, color: Color, sign: String) -> void:
	draw_rect(Rect2(x + 8, y + 8, 146, 17), Color("#e4d7bd"))
	draw_rect(Rect2(x + 15, y + 33, 132, 50), Color("#6b6257"))
	draw_rect(Rect2(x + 18, y + 37, 126, 8), color)
	for window_x in range(25, 150, 38):
		draw_rect(Rect2(x + window_x, y + 53, 21, 24), Color("#3e5152"))
	draw_rect(Rect2(x + 19, y + 11, 122, 11), Color("#f0dc82"))
	_draw_text(sign, Vector2(x + 80, y + 20), 7, Color("#57483c"), HORIZONTAL_ALIGNMENT_CENTER)


func _draw_runner_vehicle(vehicle: Dictionary) -> void:
	var position := Vector2(float(vehicle["x"]), float(vehicle["y"]))
	var width := float(vehicle["width"])
	var height := float(vehicle["height"])
	var color := Color(vehicle["color"])
	draw_rect(Rect2(position + Vector2(4, 5), Vector2(width, height)), Color("#172832"))
	draw_rect(Rect2(position + Vector2(3, 1), Vector2(width - 6, height - 3)), color)
	draw_rect(Rect2(position + Vector2(8, 9), Vector2(width - 16, 20)), Color("#91c9d0"))
	draw_rect(Rect2(position + Vector2(12, 12), Vector2(width - 24, 5)), Color("#d8f0e5"))
	draw_rect(Rect2(position + Vector2(9, height - 27), Vector2(width - 18, 15)), Color("#193b47"))
	for tire_y in [19.0, height - 32.0]:
		draw_rect(Rect2(position + Vector2(-3, tire_y), Vector2(7, 17)), Color("#111f25"))
		draw_rect(Rect2(position + Vector2(width - 4, tire_y), Vector2(7, 17)), Color("#111f25"))
	draw_rect(Rect2(position + Vector2(8, 4), Vector2(10, 5)), Color("#fff0c8"))
	draw_rect(Rect2(position + Vector2(width - 18, 4), Vector2(10, 5)), Color("#fff0c8"))
	if bool(vehicle["jeepney"]):
		draw_rect(Rect2(position + Vector2(4, 5), Vector2(width - 8, 8)), Color("#d83c3b"))
		draw_rect(Rect2(position + Vector2(9, 37), Vector2(width - 18, 5)), Color("#f4c83f"))
		_draw_text("CEBU", position + Vector2(width * 0.5, 50), 7, Color("#fff2cf"), HORIZONTAL_ALIGNMENT_CENTER)


func _draw_crossing_vehicle(vehicle: Dictionary) -> void:
	var position := Vector2(float(vehicle["x"]), float(vehicle["y"]))
	var width := float(vehicle["width"])
	var height := float(vehicle["height"])
	var color := Color(vehicle["color"])
	draw_rect(Rect2(position + Vector2(4, 4), Vector2(width, height)), Color("#20272a"))
	draw_rect(Rect2(position, Vector2(width, height)), color)
	draw_rect(Rect2(position + Vector2(10, -5), Vector2(width * 0.46, 9)), Color("#dce7df"))
	draw_rect(Rect2(position + Vector2(14, -3), Vector2(width * 0.18, 6)), Color("#8ecbd5"))
	draw_rect(Rect2(position + Vector2(8, height - 4), Vector2(14, 8)), Color("#1a2024"))
	draw_rect(Rect2(position + Vector2(width - 21, height - 4), Vector2(14, 8)), Color("#1a2024"))
	if bool(vehicle.get("jeepney", false)):
		draw_rect(Rect2(position + Vector2(5, 5), Vector2(width - 10, 8)), Color("#d83c3b"))
		draw_rect(Rect2(position + Vector2(12, 20), Vector2(width - 24, 11)), Color("#f1c53f"))
		_draw_text("CEBU", position + Vector2(width / 2, 29), 7, Color("#1a5aa4"), HORIZONTAL_ALIGNMENT_CENTER)


func _draw_student(position: Vector2, animation_time: float, large: bool) -> void:
	var scale := 1.45 if large else 1.0
	var hop := fposmod(animation_time * 5.0, 2.0) * 1.2
	var sprite_size := 72.0 * scale
	var sprite_rect := Rect2(position + Vector2(20.0 * scale - sprite_size * 0.5, -1.0 * scale - hop), Vector2(sprite_size, sprite_size))
	draw_rect(Rect2(position + Vector2(-4.0, 59.0) * scale, Vector2(40.0, 6.0) * scale), Color(0.08, 0.13, 0.14, 0.28))
	draw_texture_rect(_intro_character_texture(), sprite_rect, false)


func _draw_officer(position: Vector2, animation_time: float, close: bool, scale: float = 1.0) -> void:
	var stride := fposmod(animation_time * 5.0, 2.0)
	draw_set_transform(position, 0.0, Vector2.ONE * scale)
	draw_rect(Rect2(-5, 83, 62, 8), Color(0.08, 0.13, 0.17, 0.35))
	draw_rect(Rect2(10, 68, 13, 15 + stride * 2), Color("#172c3b"))
	draw_rect(Rect2(32, 68, 13, 15 - stride * 2), Color("#172c3b"))
	draw_rect(Rect2(6, 36, 43, 34), Color("#276548"))
	draw_rect(Rect2(10, 38, 35, 29), Color("#43885b"))
	draw_rect(Rect2(3, 40, 9, 24), Color("#43885b"))
	draw_rect(Rect2(0, 48, 8, 17), Color("#c9825f"))
	draw_rect(Rect2(44, 40, 9, 24), Color("#43885b"))
	draw_rect(Rect2(48, 48, 8, 17), Color("#c9825f"))
	draw_rect(Rect2(10, 64, 35, 6), Color("#243b36"))
	draw_rect(Rect2(12, 70, 18, 8), Color("#182c3c"))
	draw_rect(Rect2(30, 70, 16, 8), Color("#182c3c"))
	draw_rect(Rect2(10, 5, 34, 31), Color("#bd7959"))
	draw_rect(Rect2(8, 12, 4, 13), Color("#8d543e"))
	draw_rect(Rect2(42, 12, 4, 13), Color("#8d543e"))
	draw_rect(Rect2(14, 15, 5, 4), Color("#202d36"))
	draw_rect(Rect2(34, 15, 5, 4), Color("#202d36"))
	draw_rect(Rect2(25, 22, 5, 4), Color("#754638"))
	draw_rect(Rect2(7, 2, 40, 9), Color("#194b38"))
	draw_rect(Rect2(2, 8, 50, 7), Color("#2e7650"))
	draw_rect(Rect2(17, 4, 18, 4), Color("#f1d05c"))
	draw_rect(Rect2(13, 42, 8, 9), Color("#f7d653"))
	draw_rect(Rect2(24, 39, 5, 29), Color("#d7e3ce"))
	draw_rect(Rect2(32, 43, 8, 5), Color("#173f35"))
	if close:
		draw_rect(Rect2(-5, -7, 62, 4), Color("#ef5d4b"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_centered_text(text_value: String, center_x: float, baseline_y: float, font_size: int, color: Color) -> void:
	var font := _arcade_font()
	var text_width := font.get_string_size(text_value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	draw_string(font, Vector2(center_x - text_width * 0.5, baseline_y), text_value, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)


func _draw_bold_centered_text(text_value: String, center_x: float, baseline_y: float, font_size: int, color: Color) -> void:
	_draw_centered_text(text_value, center_x, baseline_y, font_size, color)
	_draw_centered_text(text_value, center_x + 1.0, baseline_y, font_size, color)


func _draw_text(text_value: String, position: Vector2, font_size: int, color: Color, alignment: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	draw_string(_arcade_font(), position, text_value, alignment, -1, font_size, color)


func _arcade_font() -> Font:
	var project_theme := ThemeDB.get_project_theme()
	if project_theme != null and project_theme.default_font != null:
		return project_theme.default_font
	return ThemeDB.fallback_font
