extends RefCounted


func add_home_button(
	parent: Control,
	text_value: String,
	callback: Callable,
	color: Color,
	text_color: Color,
	height: float
) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size.y = height
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 14)
	button.add_theme_color_override("font_color", text_color)
	button.add_theme_color_override("font_hover_color", Color("#ffffff"))
	var normal := home_button_style(color)
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", home_button_style(color.lightened(0.12)))
	button.add_theme_stylebox_override("pressed", home_button_style(color.darkened(0.16)))
	button.add_theme_stylebox_override("focus", home_button_style(color.lightened(0.12)))
	button.pressed.connect(callback)
	parent.add_child(button)
	return button


func popup_button_color(original: Color) -> Color:
	if original.is_equal_approx(Color("#e7b93e")) or original.is_equal_approx(Color("#efbd43")):
		return Color("#f5a623")
	if original.is_equal_approx(Color("#9a4b37")) or original.is_equal_approx(Color("#8e4b36")):
		return Color("#ed3348")
	if original.is_equal_approx(Color("#319274")) or original.is_equal_approx(Color("#287660")):
		return Color("#29bd68")
	return Color("#39a7d9")


func home_button_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color("#162340")
	style.set_border_width_all(3)
	style.set_corner_radius_all(0)
	style.shadow_color = Color(0.04, 0.08, 0.18, 0.75)
	style.shadow_size = 3
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 3
	style.content_margin_bottom = 3
	return style


func add_label(parent: Control, text_value: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text_value
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(label)
	return label


func add_button(
	parent: Control,
	text_value: String,
	callback: Callable,
	color: Color,
	height: float,
	building_popup: bool
) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size.y = height
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 15 if building_popup else 14)
	var button_color := popup_button_color(color) if building_popup else color
	button.add_theme_color_override("font_color", Color("#172238") if building_popup else Color("#fff9e8"))
	button.add_theme_color_override("font_hover_color", Color("#10192a") if building_popup else Color("#ffffff"))
	var normal := pixel_button_style(button_color) if building_popup else button_style(color)
	var hover := pixel_button_style(button_color.lightened(0.12)) if building_popup else button_style(color.lightened(0.12))
	var pressed := pixel_button_style(button_color.darkened(0.15)) if building_popup else button_style(color.darkened(0.15))
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override(
		"focus",
		pixel_button_style(button_color.lightened(0.12)) if building_popup else button_style(color.lightened(0.12))
	)
	button.pressed.connect(callback)
	parent.add_child(button)
	return button


func button_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color("#253c3d")
	style.set_border_width_all(2)
	style.set_corner_radius_all(3)
	style.shadow_color = Color(0.06, 0.12, 0.14, 0.55)
	style.shadow_size = 3
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 5
	style.content_margin_bottom = 5
	return style


func apply_panel_style(control: Control, color: Color, border: Color) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(4)
	style.set_corner_radius_all(4)
	style.shadow_color = Color(0.04, 0.09, 0.10, 0.8)
	style.shadow_size = 6
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	control.add_theme_stylebox_override("panel", style)


func apply_pixel_popup_style(control: Control, background: Color, border: Color) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = border
	style.set_border_width_all(4)
	style.set_corner_radius_all(0)
	style.shadow_color = Color("#09162e")
	style.shadow_size = 7
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	control.add_theme_stylebox_override("panel", style)


func pixel_button_style(background: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = Color("#182238")
	style.set_border_width_all(4)
	style.set_corner_radius_all(0)
	style.shadow_color = Color("#091326")
	style.shadow_size = 4
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	return style


func add_keycap(parent: Control, key_text: String, on_press: Callable, on_release: Callable) -> Button:
	var button := Button.new()
	button.text = key_text
	button.custom_minimum_size = Vector2(36, 36)
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_font_size_override("font_size", 20)
	button.add_theme_color_override("font_color", Color("#fff1ed"))
	button.add_theme_color_override("font_hover_color", Color("#ffffff"))
	var normal := _keycap_style(Color("#b84761"))
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", _keycap_style(Color("#c75570")))
	button.add_theme_stylebox_override("pressed", _keycap_style(Color("#96334c")))
	button.add_theme_stylebox_override("focus", normal)
	button.button_down.connect(on_press)
	button.button_up.connect(on_release)
	parent.add_child(button)
	return button


func _keycap_style(background: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = Color("#20171c")
	style.set_border_width_all(3)
	style.set_corner_radius_all(0)
	style.shadow_color = Color("#171319")
	style.shadow_size = 3
	style.content_margin_left = 2
	style.content_margin_right = 2
	style.content_margin_top = 2
	style.content_margin_bottom = 2
	return style
