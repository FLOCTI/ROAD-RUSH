extends SceneTree

var failures: Array[String] = []


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var packed_scene := load("res://scenes/main.tscn") as PackedScene
	_check(packed_scene != null, "main scene loads")
	if packed_scene == null:
		_finish()
		return

	var game := packed_scene.instantiate()
	if game.get_script() == null:
		_check(false, "main game script loads")
		_finish()
		return
	root.add_child(game)
	await process_frame

	var project_theme := ThemeDB.get_project_theme()
	_check(project_theme != null and project_theme.default_font is FontVariation, "the project theme uses the arcade display font")
	if project_theme != null and project_theme.default_font is FontVariation:
		var arcade_font := project_theme.default_font as FontVariation
		var ascii_glyphs_present := true
		for codepoint in range(32, 127):
			ascii_glyphs_present = ascii_glyphs_present and arcade_font.has_char(codepoint)
		_check(ascii_glyphs_present, "the arcade font supports the full basic character set")
		_check(not arcade_font.fallbacks.is_empty(), "missing symbols retain a readable fallback font")
	_check(game.get("mode") == "home", "game opens at the title screen")
	_check(InputMap.has_action("move_left") and InputMap.has_action("move_up"), "movement actions are configured")
	_check(
		_has_physical_key("move_up", KEY_W)
		and _has_physical_key("move_left", KEY_A)
		and _has_physical_key("move_down", KEY_S)
		and _has_physical_key("move_right", KEY_D),
		"WASD keys match the crossing guide"
	)
	_check(game.get("intro_active"), "the opening cinematic starts automatically")
	_check(not (game.get("screen_root") as Control).visible, "home menu stays hidden during the cinematic")
	var home_logo_position: Vector2 = game.call("_home_logo_position")
	var logo_size: Vector2 = game.get("WORDMARK_SIZE")
	_check(is_equal_approx(home_logo_position.x + logo_size.x * 0.5, 480.0), "main menu logo is centered within the game viewport")
	_check(home_logo_position.x >= 0.0 and home_logo_position.x + logo_size.x <= 960.0, "main menu logo fits without horizontal clipping")
	var intro_logo_start: Dictionary = game.call("_intro_logo_transform", 2.0)
	var intro_logo_settle: Dictionary = game.call("_intro_logo_transform", 2.8)
	var intro_logo_impact_end: Dictionary = game.call("_intro_logo_transform", 3.12)
	var intro_start_position: Vector2 = intro_logo_start["position"]
	var intro_settle_position: Vector2 = intro_logo_settle["position"]
	_check(intro_start_position.x > intro_settle_position.x, "intro logo slides into its centered position")
	_check(is_equal_approx(intro_settle_position.x + logo_size.x * float(intro_logo_settle["scale"]) * 0.5, 480.0), "intro logo settles centered without changing proportions")
	_check(is_equal_approx(float(intro_logo_start["scale"]), 0.82) and is_equal_approx(float(intro_logo_settle["scale"]), 1.0), "intro logo uses a uniform, proportional scale entrance")
	_check(float(intro_logo_settle["impact"]) > 0.99 and is_equal_approx(float(intro_logo_impact_end["impact"]), 0.0), "intro logo impact effect is brief and settles cleanly")
	_check(
		is_equal_approx(5.5 - float(game.get("INTRO_DURATION")), 2.0)
		and game.get("INTRO_DURATION") == 3.5
		and game.get("INTRO_LOGO_START") == 2.0,
		"intro is shortened by exactly two seconds while keeping the logo slide duration"
	)
	_check(
		game.get("INTRO_RUNNER_START") < game.get("INTRO_OFFICER_START")
		and game.get("INTRO_OFFICER_START") < game.get("INTRO_LOGO_START")
		and is_equal_approx(
			float(game.get("INTRO_FADE_OUT_START")),
			float(game.get("INTRO_LOGO_START"))
				+ float(game.get("INTRO_LOGO_SLIDE_DURATION"))
				+ float(game.get("INTRO_LOGO_IMPACT_DURATION"))
		)
		and is_equal_approx(
			float(game.get("INTRO_FADE_OUT_START")) + float(game.get("INTRO_FADE_OUT_DURATION")),
			float(game.get("INTRO_DURATION"))
		),
		"intro keeps runner, officer, title, and fade events in order through the exact end time"
	)
	var runner_start: Vector2 = game.call("_intro_runner_position", 0.0)
	var runner_later: Vector2 = game.call("_intro_runner_position", 2.5)
	_check(runner_start.y >= 446.0 and runner_later.y == runner_start.y, "intro runner stays grounded on the road")
	_check(runner_later.y <= 540.0, "intro runner stays within the road scene")
	_check(runner_later.x > runner_start.x, "intro runner travels across the road")
	_check(game.get("INTRO_CHARACTER_SIZE") == Vector2(144, 144), "intro characters use the larger animation scale")
	var officer_position: Vector2 = game.call("_intro_officer_position", 2.5)
	var jeepney_position: Vector2 = game.call("_intro_jeepney_position", 2.5)
	var later_jeepney_position: Vector2 = game.call("_intro_jeepney_position", 3.2)
	var jeepney_size: Vector2 = game.get("INTRO_JEEPNEY_SIZE")
	_check(jeepney_size.y > 83.0 * float(game.get("INTRO_OFFICER_SCALE")) and jeepney_size.y > float(game.get("INTRO_CHARACTER_SIZE").y), "intro jeepney towers over both running characters")
	_check(jeepney_position.y + jeepney_size.y <= 498.0 and jeepney_position.y + jeepney_size.y >= 494.0, "intro jeepney stays grounded as its suspension bounces")
	var chase_gap := officer_position.x - (jeepney_position.x + jeepney_size.x)
	_check(jeepney_position.x < officer_position.x and jeepney_position.x + jeepney_size.x < runner_later.x, "intro jeepney follows the officer behind the student")
	_check(absf(chase_gap - float(game.get("INTRO_JEEPNEY_CHASE_GAP"))) <= 2.0, "intro jeepney keeps a tight, clear gap behind the officer")
	_check(later_jeepney_position.x > jeepney_position.x, "intro jeepney moves with the chase")
	_check(not is_equal_approx(later_jeepney_position.y, jeepney_position.y), "intro jeepney suspension animates during the pursuit")
	_check(is_equal_approx(officer_position.y + 83.0 * float(game.get("INTRO_OFFICER_SCALE")), 496.0), "intro officer stays grounded at the larger scale")
	var girl_sprite := game.call("_intro_character_texture") as Texture2D
	_check(girl_sprite != null and girl_sprite.get_size() == Vector2(512, 512), "intro uses the complete character sprite")
	game.set("selected_character", "boy")
	var boy_sprite := game.call("_intro_character_texture") as Texture2D
	_check(boy_sprite != null and boy_sprite != girl_sprite, "intro preserves the selected character design")
	game.set("selected_character", "girl")
	game.call("_start_crossing")
	_check(game.get("mode") == "home", "gameplay cannot start before the intro finishes")
	game.set("intro_elapsed", 3.49)
	game.call("_process", 0.0)
	_check(game.get("intro_active"), "the intro remains active until its shortened duration")
	game.call("_process", 0.01)
	_check(not game.get("intro_active"), "the opening cinematic finishes after 3.5 seconds")
	_check((game.get("screen_root") as Control).visible, "home menu appears after the cinematic")
	var runner_challenge_button: Button
	var achievements_button: Button
	for candidate in game.get("screen_root").find_children("*", "Button", true, false):
		if (candidate as Button).text == "RUNNER CHALLENGE":
			runner_challenge_button = candidate as Button
		if (candidate as Button).text == "ACHIEVEMENTS":
			achievements_button = candidate as Button
	_check(runner_challenge_button != null, "main menu provides the runner challenge")
	_check(achievements_button != null, "main menu provides achievements")
	if runner_challenge_button != null:
		runner_challenge_button.emit_signal("pressed")
	_check(game.get("mode") == "chase" and game.get("wallet") == 150 and game.get("mini_game_mode"), "mini game starts with a fresh allowance and endless-run mode")
	var runner_keypad := game.get("screen_root").find_child("WASDKeyLayout", true, false) as GridContainer
	_check(runner_keypad != null, "runner challenge shows the WASD key pad")
	if runner_keypad != null:
		var runner_y_before_click := float(game.get("player_y"))
		var runner_w_key := runner_keypad.find_child("KeyW", true, false) as Button
		runner_w_key.emit_signal("button_down")
		game.call("_update_chase", 0.05)
		runner_w_key.emit_signal("button_up")
		_check(float(game.get("player_y")) < runner_y_before_click, "clicking W moves the runner up")
		var runner_s_key := runner_keypad.find_child("KeyS", true, false) as Button
		runner_s_key.emit_signal("button_down")
		game.call("_update_chase", 0.05)
		runner_s_key.emit_signal("button_up")
		_check(is_equal_approx(float(game.get("player_y")), runner_y_before_click), "clicking S moves the runner down")
	game.call("_go_home")
	for candidate in game.get("screen_root").find_children("*", "Button", true, false):
		if (candidate as Button).text == "ACHIEVEMENTS":
			(candidate as Button).emit_signal("pressed")
			break
	var mini_leaderboard_text := ""
	for label in game.get("screen_root").find_children("*", "Label", true, false):
		mini_leaderboard_text += (label as Label).text + "\n"
	_check(mini_leaderboard_text.contains("MINI GAME LEADERBOARD") and mini_leaderboard_text.contains("LONGEST RUN") and mini_leaderboard_text.contains("HIGHEST MONEY COLLECTED") and mini_leaderboard_text.contains("FASTEST ON-TIME"), "achievements menu includes both separate main-game and mini-game records")
	game.call("_popup_back")
	game.call("_go_home")
	var how_to_play_button: Button
	for candidate in game.get("screen_root").find_children("*", "Button", true, false):
		if (candidate as Button).text == "HOW TO PLAY":
			how_to_play_button = candidate as Button
			break
	_check(how_to_play_button != null, "main menu exposes the game instructions as HOW TO PLAY")
	if how_to_play_button != null:
		how_to_play_button.emit_signal("pressed")
	var instruction_labels: Array = game.get("screen_root").find_children("*", "Label", true, false)
	var instruction_text := ""
	for instruction_label in instruction_labels:
		instruction_text += (instruction_label as Label).text + "\n"
	_check(instruction_text.contains("Cross only on red") and instruction_text.contains("three-second officer-catch scene"), "instructions explain legal crossing and the jaywalking chase transition")
	_check(instruction_text.contains("Use WASD or arrows") and instruction_text.contains("move up/down") and instruction_text.contains("₱150"), "instructions include runner controls and allowance rules")
	for panel in ["profile", "create_profile", "character", "options", "achievements", "help", "pause", "allowance", "won", "gameover"]:
		game.call("_open_overlay", panel)
		if panel == "pause":
			await process_frame
		_check(game.get("overlay") == panel, "%s menu opens" % panel)
		_check(not (game.call("_popup_title") as String).is_empty(), "%s popup has a title" % panel)
		var popup_size: Vector2 = game.call("_popup_size")
		_check(popup_size.x <= 650 and popup_size.y <= 420, "%s popup uses a compact layout" % panel)
		var pixel_badge := game.get("screen_root").find_child("PixelBadge", true, false) as HBoxContainer
		_check(pixel_badge != null and pixel_badge.get_child_count() == 3, "%s popup has a pixel-game header badge" % panel)
		var popup_card := game.get("screen_root").find_child("ArcadePopup", true, false) as Control
		_check(
			popup_card.position.is_equal_approx((Vector2(960, 540) - popup_size) * 0.5)
			and popup_card.size.is_equal_approx(popup_size),
			"%s popup is centered at its requested size" % panel
		)
		var popup_style := popup_card.get_theme_stylebox("panel") as StyleBoxFlat
		_check(popup_style.bg_color == Color("#fff5dc"), "%s popup keeps its light pixel panel background" % panel)
		for candidate in popup_card.find_children("*", "Button", true, false):
			var button_style := (candidate as Button).get_theme_stylebox("normal") as StyleBoxFlat
			if button_style != null:
				_check(button_style.corner_radius_top_left == 0 and button_style.border_width_left == 4, "%s buttons use chunky pixel borders" % panel)
				break
		var scrolls: Array = game.get("screen_root").find_children("*", "ScrollContainer", true, false)
		_check(not scrolls.is_empty(), "%s popup content is scrollable" % panel)
		var panels: Array = game.get("screen_root").find_children("*", "PanelContainer", true, false)
		_check(panels.size() >= 2, "%s popup has a framed panel and title tab" % panel)
		if not panels.is_empty():
			var popup := panels[0] as Control
			_check(popup.custom_minimum_size.x <= 960 and popup.custom_minimum_size.y <= 540, "%s popup fits the game viewport" % panel)
		if panel == "pause":
			var pause_scrolls := popup_card.find_children("*", "ScrollContainer", true, false)
			var pause_buttons: Array = popup_card.find_children("*", "Button", true, false)
			var pause_contents_visible := not pause_scrolls.is_empty()
			if not pause_scrolls.is_empty():
				pause_contents_visible = (pause_scrolls[0] as ScrollContainer).size.y >= 180.0
			for pause_button in pause_buttons:
				pause_contents_visible = pause_contents_visible and (pause_button as Button).visible and (pause_button as Button).size.y >= 34.0
			_check(pause_buttons.size() >= 5 and pause_contents_visible, "pause popup displays its full set of usable buttons")
	if game.get("overlay") == "gameover":
		_check(game.call("_popup_title") == "RUN ENDED", "main game-over popup uses a bold arcade title")
		_check(game.get("screen_root").find_child("PopupStatRunDistance", true, false) != null, "main game-over popup shows a distance stat card")
		_check(game.get("screen_root").find_child("PopupStatAllowance", true, false) != null, "main game-over popup shows the remaining allowance")
	game.set("mini_game_mode", true)
	game.call("_open_overlay", "gameover")
	_check(game.call("_popup_title") == "GAME OVER", "mini-game popup uses the arcade game-over title")
	_check(game.get("screen_root").find_child("PopupStatRunDistance", true, false) != null, "mini-game popup shows the run distance stat card")
	_check(game.get("screen_root").find_child("PopupStatCoins", true, false) != null, "mini-game popup shows collected money")
	var retry_button: Button
	var menu_button: Button
	for candidate in game.get("screen_root").find_child("ArcadePopup", true, false).find_children("*", "Button", true, false):
		if (candidate as Button).text == "RUN AGAIN":
			retry_button = candidate as Button
		elif (candidate as Button).text == "MAIN MENU":
			menu_button = candidate as Button
	var retry_style := retry_button.get_theme_stylebox("normal") as StyleBoxFlat if retry_button != null else null
	var menu_style := menu_button.get_theme_stylebox("normal") as StyleBoxFlat if menu_button != null else null
	_check(
		retry_style != null
		and retry_style.bg_color == Color("#f5a623")
		and menu_style != null
		and menu_style.bg_color == Color("#ed3348"),
		"game-over actions use bright arcade button colors"
	)
	game.set("mini_game_mode", false)
	game.call("_open_overlay", "gameover")
	game.call("_popup_back")
	_check(game.get("overlay") == "", "closing a popup returns to the current screen")
	game.call("_open_overlay", "create_profile")
	var name_input := game.get("screen_root").find_child("ProfileName", true, false) as LineEdit
	var save_player: Button
	for candidate in game.get("screen_root").find_children("*", "Button", true, false):
		if (candidate as Button).text == "SAVE PLAYER":
			save_player = candidate as Button
			break
	_check(name_input != null and save_player != null, "profile form is built")
	if name_input != null and save_player != null:
		name_input.text = "TEST PLAYER"
		save_player.emit_signal("pressed")
	_check((game.get("profiles") as Array).size() == 1, "a local player profile can be created")
	_check(game.get("player_name") == "TEST PLAYER", "the selected profile is active")
	game.call("_open_overlay", "create_profile")
	game.call("_popup_back")
	_check(game.get("overlay") == "profile", "back from profile creation returns to the profile list")
	if (game.get("profiles") as Array).is_empty():
		_finish()
		return
	game.call("_delete_profile", str((game.get("profiles") as Array)[0].get("id", "")))
	_check((game.get("profiles") as Array).is_empty(), "a local player profile can be deleted")

	game.call("_start_new_cycle")
	await process_frame
	_check(game.get("mode") == "crossing", "starting a run opens the crossing")
	_check(game.get("wallet") == 150 and game.get("attempts_remaining") == 3, "a new cycle starts with ₱150 and three attempts")
	_check(game.get("player_y") == 390.0, "the student starts on the near sidewalk")
	var controls_guide := game.get("screen_root").find_child("WASDControlsGuide", true, false) as Control
	_check(controls_guide != null and controls_guide.visible, "the WASD guide appears during the crossing")
	_check(controls_guide.position == Vector2(826, 451) and controls_guide.size == Vector2(122, 81), "the WASD guide sits at bottom right")
	var crossing_pause_button: Button
	for candidate in game.get("screen_root").find_children("*", "Button", true, false):
		if (candidate as Button).text == "PAUSE":
			crossing_pause_button = candidate as Button
			break
	_check(
		crossing_pause_button != null
		and crossing_pause_button.custom_minimum_size == Vector2(174, 52)
		and crossing_pause_button.size.is_equal_approx(Vector2(174, 52))
		and crossing_pause_button.get_theme_font_size("font_size") == 14,
		"crossing pause button matches the compact runner pause button size"
	)
	if controls_guide != null:
		var key_layout := controls_guide.find_child("WASDKeyLayout", true, false) as GridContainer
		_check(
			key_layout != null
			and controls_guide.find_child("KeyW", true, false) != null
			and controls_guide.find_child("KeyA", true, false) != null
			and controls_guide.find_child("KeyS", true, false) != null
			and controls_guide.find_child("KeyD", true, false) != null,
			"the crossing guide shows the W-over-A-S-D key layout"
		)
		if key_layout != null:
			_check(
				(key_layout.get_child(1) as Control).name == "KeyW"
				and (key_layout.get_child(3) as Control).name == "KeyA"
				and (key_layout.get_child(4) as Control).name == "KeyS"
				and (key_layout.get_child(5) as Control).name == "KeyD",
				"the WASD keycaps match the supplied keypad arrangement"
			)
		var click_w := controls_guide.find_child("KeyW", true, false) as Button
		var click_s := controls_guide.find_child("KeyS", true, false) as Button
		var click_a := controls_guide.find_child("KeyA", true, false) as Button
		var click_d := controls_guide.find_child("KeyD", true, false) as Button
		var crossing_start_position := Vector2(float(game.get("player_x")), float(game.get("player_y")))
		click_w.emit_signal("button_down")
		game.call("_update_crossing", 0.05)
		click_w.emit_signal("button_up")
		_check(float(game.get("player_y")) < crossing_start_position.y, "clicking W moves up during the crossing")
		click_s.emit_signal("button_down")
		game.call("_update_crossing", 0.05)
		click_s.emit_signal("button_up")
		_check(is_equal_approx(float(game.get("player_y")), crossing_start_position.y), "clicking S moves down during the crossing")
		click_a.emit_signal("button_down")
		game.call("_update_crossing", 0.05)
		click_a.emit_signal("button_up")
		_check(float(game.get("player_x")) < crossing_start_position.x, "clicking A moves left during the crossing")
		click_d.emit_signal("button_down")
		game.call("_update_crossing", 0.05)
		click_d.emit_signal("button_up")
		_check(is_equal_approx(float(game.get("player_x")), crossing_start_position.x), "clicking D moves right during the crossing")
		game.set("player_x", crossing_start_position.x)
		game.set("player_y", crossing_start_position.y)
	var spawned_crossing_coins: Array = game.get("crossing_coins")
	var coin_rows := {}
	var coins_outside_lane_and_on_road := true
	var coins_clear_of_signs_and_traffic := true
	var roadside_coins_reachable := true
	var coin_left_of_lane := false
	var coin_right_of_lane := false
	var coins_warning_rect: Rect2 = game.get("CROSSING_WARNING_RECT")
	var coins_signal_rect: Rect2 = game.get("CROSSING_SIGNAL_RECT")
	for coin in spawned_crossing_coins:
		var coin_rect := Rect2(Vector2(float(coin["x"]), float(coin["y"])), Vector2(18, 18))
		var outside_lane := coin_rect.end.x <= float(game.get("CROSSWALK_LEFT")) or coin_rect.position.x >= float(game.get("CROSSWALK_RIGHT"))
		coin_left_of_lane = coin_left_of_lane or coin_rect.end.x <= float(game.get("CROSSWALK_LEFT"))
		coin_right_of_lane = coin_right_of_lane or coin_rect.position.x >= float(game.get("CROSSWALK_RIGHT"))
		var on_road := coin_rect.position.y >= float(game.get("CROSSING_ROAD_TOP")) and coin_rect.end.y <= float(game.get("CROSSING_ROAD_BOTTOM"))
		coins_outside_lane_and_on_road = coins_outside_lane_and_on_road and outside_lane and on_road
		coins_clear_of_signs_and_traffic = coins_clear_of_signs_and_traffic and not coin_rect.intersects(coins_warning_rect) and not coin_rect.intersects(coins_signal_rect)
		var candidate_player_x := clampf(float(coin["x"]) - 8.0, 14.0, 912.0)
		var candidate_player_y := clampf(float(coin["y"]) - 25.0, 48.0, 470.0)
		var candidate_player_rect := Rect2(candidate_player_x + 7.0, candidate_player_y + 7.0, 20.0, 52.0)
		roadside_coins_reachable = roadside_coins_reachable and candidate_player_rect.intersects(coin_rect)
		for vehicle in game.get("crossing_cars"):
			var vehicle_rect := Rect2(float(vehicle["x"]), float(vehicle["y"]), float(vehicle["width"]), float(vehicle["height"]))
			coins_clear_of_signs_and_traffic = coins_clear_of_signs_and_traffic and not coin_rect.intersects(vehicle_rect)
		coin_rows[float(coin["y"])] = true
	_check(spawned_crossing_coins.size() == 7 and coins_outside_lane_and_on_road, "crossing coins spawn in the road outside the pedestrian lane")
	_check(coin_left_of_lane and coin_right_of_lane, "roadside coins are scattered along both sides of the pedestrian lane")
	_check(roadside_coins_reachable, "every roadside coin is reachable from the starting sidewalk")
	_check(coins_clear_of_signs_and_traffic, "roadside coins do not overlap warning signs or vehicles")
	_check(coin_rows.size() >= 3, "roadside coins are staggered across several rows")
	var upper_vehicle := {
		"x": float(game.get("player_x")),
		"y": float(game.get("player_y")),
		"width": 72.0,
		"height": 34.0,
	}
	_check(not game.call("_crossing_collision", upper_vehicle), "touching a car with only the student's head does not cause a crossing collision")
	upper_vehicle["y"] = float(game.get("player_y")) + 18.0
	_check(game.call("_crossing_collision", upper_vehicle), "crossing collision still registers against the student's lower body")
	var crossing_cars_at_start: Array = game.get("crossing_cars")
	var bottom_lane_clear := true
	var car_widths: Array[float] = []
	for vehicle in crossing_cars_at_start:
		car_widths.append(float(vehicle["width"]))
		if float(vehicle["y"]) >= 374.0:
			bottom_lane_clear = bottom_lane_clear and float(vehicle["y"]) + float(vehicle["height"]) <= float(game.get("CROSSING_ROAD_BOTTOM"))
	_check(bottom_lane_clear, "bottom-lane traffic stays inside the road and clear of sidewalk signals")
	_check(car_widths.has(78.0) and car_widths.has(156.0), "crossing lanes use mixed short cars and long vehicles")
	var crossing_hud: Dictionary = game.get("hud_labels")
	_check(
		(crossing_hud["wallet"] as Label).get_theme_color("font_color") == Color("#ffd54f")
		and (crossing_hud["attempts"] as Label).get_theme_color("font_color") == Color("#ffd54f"),
		"allowance and attempts are highlighted in yellow"
	)
	var wallet_card := (crossing_hud["wallet"] as Label).get_parent() as PanelContainer
	var attempts_card := (crossing_hud["attempts"] as Label).get_parent() as PanelContainer
	var wallet_card_style := wallet_card.get_theme_stylebox("panel") as StyleBoxFlat
	var attempts_card_style := attempts_card.get_theme_stylebox("panel") as StyleBoxFlat
	var crossing_bar := wallet_card.get_parent() as HBoxContainer
	_check(
		wallet_card_style.bg_color == Color("#70472f") and attempts_card_style.bg_color == Color("#70472f"),
		"crossing allowance and attempts counters use brown pixel panels"
	)
	_check(
		wallet_card.size.x >= 110.0
		and attempts_card.size.x >= 170.0
		and crossing_bar.size.y <= 64.0
		and (crossing_hud["wallet"] as Label).autowrap_mode == TextServer.AUTOWRAP_OFF
		and (crossing_hud["attempts"] as Label).autowrap_mode == TextServer.AUTOWRAP_OFF,
		"crossing allowance and attempts stay horizontal in a compact HUD row"
	)
	var signal_rect: Rect2 = game.get("CROSSING_SIGNAL_RECT")
	var warning_rect: Rect2 = game.get("CROSSING_WARNING_RECT")
	_check(signal_rect.size.x > signal_rect.size.y, "crossing signal lights are arranged horizontally")
	_check(signal_rect.position.y >= 416.0 and signal_rect.end.y <= 464.0, "enlarged signal stays visible on the lower sidewalk")
	_check(warning_rect.position.y >= 416.0 and warning_rect.end.y <= 464.0, "enlarged warning placard stays visible on the lower sidewalk")
	_check(signal_rect.size.x >= 170.0 and signal_rect.size.y >= 48.0, "warning signal is larger while retaining its proportions")
	_check(warning_rect.size.x >= 200.0 and warning_rect.size.y >= 48.0, "warning placard is larger while retaining its proportions")
	var warning_font := game.call("_arcade_font") as Font
	var warning_line_width := warning_font.get_string_size("WARNING! THE TRAFFIC", HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x
	_check(warning_line_width <= warning_rect.size.x - 16.0, "warning text fits inside the enlarged placard")
	var controls_rect := Rect2(controls_guide.position, controls_guide.size)
	_check(not controls_rect.intersects(warning_rect) and not controls_rect.intersects(signal_rect), "bottom-right WASD guide stays clear of both warning signs")
	var hit_rect: Rect2 = game.get("CROSSING_HIT_RECT")
	_check(is_equal_approx(hit_rect.get_center().x, 480.0), "watch-the-traffic warning is centered on its red placard")
	_check(float(game.get("SIGNAL_GREEN_DURATION")) >= 5.0 and float(game.get("SIGNAL_RED_DURATION")) >= 5.0, "green and red signal phases last at least five seconds")
	_check(game.call("_signal_is_green"), "the broken signal starts on its misleading green phase")
	game.set("signal_elapsed", 6.99)
	_check(game.call("_signal_is_green"), "the green phase remains on for seven seconds")
	game.set("signal_elapsed", 7.0)
	_check(game.call("_signal_is_yellow") and not game.call("_signal_is_red"), "the yellow phase follows green and is unsafe to cross")
	game.set("signal_elapsed", 7.99)
	_check(game.call("_signal_is_yellow"), "yellow remains on for its full phase")
	game.set("signal_elapsed", 8.0)
	_check(game.call("_signal_is_red"), "the red phase begins after yellow")
	game.set("signal_elapsed", 12.99)
	_check(game.call("_signal_is_red"), "the red phase remains on for five seconds")
	game.set("signal_elapsed", 13.0)
	_check(game.call("_signal_is_green"), "the signal cycle repeats after thirteen seconds")
	game.set("signal_elapsed", 0.0)
	_check((game.get("crossing_cars") as Array).size() >= 8, "crossing traffic is populated")
	var paint_stripes: Array = game.get("CROSSWALK_PAINT_STRIPES")
	var two_block_stripe_exists := false
	var stripe_lengths_vary := false
	for stripe_index in range(paint_stripes.size()):
		var stripe: Vector2 = paint_stripes[stripe_index]
		two_block_stripe_exists = two_block_stripe_exists or stripe.y >= 2.0 * float(game.get("CROSSWALK_PAINT_BLOCK_SIZE"))
		if stripe_index > 0:
			var previous_stripe: Vector2 = paint_stripes[stripe_index - 1]
			stripe_lengths_vary = stripe_lengths_vary or stripe.y != previous_stripe.y
	_check(two_block_stripe_exists and stripe_lengths_vary, "crosswalk paint has varied stripe lengths and at least two white blocks")

	var crossing_cars: Array = game.get("crossing_cars")
	crossing_cars.clear()
	game.set("player_x", 500.0)
	game.set("player_y", 355.0)
	crossing_cars.append({
		"x": 495.0,
		"y": 355.0,
		"width": 60.0,
		"height": 64.0,
		"speed": 0.0,
		"color": Color("#e85d4b"),
	})
	game.set("crossing_cars", crossing_cars)
	game.call("_update_crossing", 0.0)
	_check(game.get("player_x") == 716.0 and game.get("player_y") == 390.0, "a traffic collision resets the crossing position")
	_check(game.get("wallet") == 150 and game.get("attempts_remaining") == 3, "a crossing collision does not count as an officer capture")

	game.set("crossing_cars", [])
	var forced_coins: Array[Dictionary] = [{"x": 716.0, "y": 390.0}]
	game.set("crossing_coins", forced_coins)
	game.call("_update_crossing", 0.0)
	_check(game.get("wallet") == 155 and (game.get("crossing_coins") as Array).is_empty(), "collecting a crossing coin adds ₱5 to the allowance")

	game.call("_start_new_cycle")
	game.set("crossing_cars", [])
	game.set("player_x", 500.0)
	game.set("player_y", 361.0)
	game.set("signal_elapsed", 8.0)
	Input.action_press("move_right")
	game.call("_update_crossing", 0.05)
	Input.action_release("move_right")
	_check(game.get("crossing_jaywalking"), "stepping outside the painted crossing is jaywalking, even during red")

	game.call("_start_new_cycle")
	game.set("crossing_cars", [])
	game.set("player_x", 450.0)
	game.set("signal_elapsed", 0.0)
	Input.action_press("move_up")
	game.call("_update_crossing", 0.1)
	Input.action_release("move_up")
	_check(game.get("crossing_jaywalking"), "entering the white crossing on green is jaywalking")
	game.call("_start_new_cycle")
	game.set("crossing_cars", [])
	game.set("player_x", 450.0)
	game.set("player_y", 361.0)
	game.set("signal_elapsed", 7.0)
	game.call("_update_crossing", 0.0)
	_check(game.get("crossing_jaywalking"), "standing on the road during yellow is jaywalking")
	game.call("_start_new_cycle")
	game.set("crossing_cars", [])
	game.set("player_x", 540.0)
	game.set("player_y", 361.0)
	game.set("signal_elapsed", 8.1)
	game.call("_update_crossing", 0.0)
	_check(game.get("crossing_jaywalking"), "standing off the white crossing during red is jaywalking")
	game.set("player_y", 52.0)
	game.call("_update_crossing", 0.0)
	_check(game.get("mode") == "jaywalk_catch" and game.get("overlay") == "", "a jaywalking crossing immediately starts the officer-catch animation without a popup")
	_check(game.get("fastest_arrival_time") == 0.0, "a jaywalking crossing does not set the on-time record")
	_check(game.get("JAYWALK_CATCH_DURATION") == 3.0, "the officer-catch transition lasts three seconds")
	_check(not (game.get("screen_root") as Control).visible, "the crossing menu is hidden during the officer-catch animation")
	game.queue_redraw()
	await process_frame
	var catch_time_remaining := float(game.get("JAYWALK_CATCH_DURATION")) - float(game.get("jaywalk_catch_elapsed"))
	game.call("_process", maxf(0.0, catch_time_remaining - 0.01))
	_check(game.get("mode") == "jaywalk_catch", "the officer-catch animation continues for the full three seconds")
	game.call("_process", 0.02)
	_check(game.get("mode") == "chase" and game.get("overlay") == "", "the officer-catch animation transitions directly to the runner without a popup")
	_check(game.get("wallet") == 150 and game.get("attempts_remaining") == 3, "the jaywalking chase preserves the crossing allowance and attempts")
	_check(game.get("screen_root").find_child("WASDControlsGuide", true, false) != null, "the WASD key pad stays visible in the runner chase")

	game.call("_start_new_cycle")
	game.set("crossing_cars", [])
	game.set("player_x", 450.0)
	game.set("signal_elapsed", 8.1)
	Input.action_press("move_up")
	game.call("_update_crossing", 0.1)
	Input.action_release("move_up")
	_check(not game.get("crossing_jaywalking"), "red permits entering on the white crossing")
	game.set("signal_elapsed", 12.9)
	game.call("_update_crossing", 0.2)
	_check(game.get("crossing_jaywalking"), "a signal changing from red to green during the crossing makes it jaywalking")
	game.call("_start_new_cycle")
	game.set("crossing_cars", [])
	game.set("player_x", 450.0)
	game.set("signal_elapsed", 8.1)
	Input.action_press("move_up")
	game.call("_update_crossing", 0.1)
	Input.action_release("move_up")
	_check(not game.get("crossing_jaywalking"), "the red phase allows a lawful crossing on the painted path")
	game.set("player_y", 52.0)
	game.call("_update_crossing", 0.0)
	_check(game.get("mode") == "celebration", "reaching the sidewalk starts the school arrival celebration")
	_check(not game.get("crossing_jaywalking") and game.get("fastest_arrival_time") > 0.0, "a lawful crossing records an on-time arrival")
	_check(game.call("_arrival_message") == "YOU MADE IT ON TIME!", "lawful arrival celebrates making it on time")
	_check(game.get("wallet") == 150, "crossing without collecting coins preserves the starting allowance")
	var arrival_start: Vector2 = game.call("_arrival_student_position", 0.0)
	var arrival_finish: Vector2 = game.call("_arrival_student_position", 2.7)
	_check(arrival_start.x < 0.0 and arrival_finish.x >= 619.0 and arrival_finish.x <= 665.0, "arrival animation ends in the UV building doorway")
	_check(arrival_finish.y == 385.0 and game.call("_arrival_student_scale", 2.7) < 0.6, "student stays grounded in the doorway at the end of the animation")
	game.queue_redraw()
	await process_frame
	_check(game.get("mode") == "celebration", "the school arrival animation renders")
	game.call("_process", 4.01)
	_check(game.get("mode") == "home" and game.get("overlay") == "", "the four-second crossing celebration returns to the main menu")

	game.call("_start_chase")
	_check(game.get("mode") == "chase", "the post-crossing phase starts the 2D traffic chase")
	_check(game.get("screen_root").find_child("WASDKeyLayout", true, false) != null, "the main runner chase shows the WASD key pad")
	_check(game.get("wallet") == 150, "a fresh runner challenge starts with ₱150 allowance")
	_check(game.get("time_left") == 120.0, "the traffic run begins at two minutes")
	_check(game.get("player_y") == 390.0, "the runner begins on the roadway")
	var runner_coins: Array = game.get("runner_coins")
	_check(runner_coins.size() >= 3, "the chase begins with collectible coins on the road")
	var starting_wallet := int(game.get("wallet"))
	runner_coins.append({
		"x": float(game.get("player_x")) + 8.0,
		"y": float(game.get("player_y")) + 8.0,
	})
	game.set("runner_coins", runner_coins)
	game.call("_collect_runner_coins")
	_check(game.get("wallet") == starting_wallet + 2, "collecting a chase coin adds ₱2 to the allowance")
	_check(int(game.get("highest_allowance")) >= starting_wallet + 2, "runner coin pickups update the allowance record")
	game.call("_sync_hud")
	_check(str((game.get("hud_labels")["wallet"] as Label).text) == "₱152", "runner coin pickups immediately update the allowance HUD")
	for player_position in [198.0, 353.0, 468.0, 698.0]:
		game.set("player_x", player_position)
		game.set("officer_x", player_position)
		var officer_rect := Rect2(game.call("_runner_officer_position"), Vector2(56, 86) * float(game.get("RUNNER_OFFICER_SCALE")))
		var student_rect := Rect2(Vector2(player_position - 16.0, float(game.get("player_y")) - 1.0), Vector2(72, 72))
		_check(not officer_rect.intersects(student_rect), "the officer follows behind without overlapping at each lane")
		_check(absf(officer_rect.get_center().x - student_rect.get_center().x) < 2.0 and officer_rect.position.y > student_rect.end.y, "the officer chases from behind on the same path")
	_check(absf(86.0 * float(game.get("RUNNER_OFFICER_SCALE")) - 72.0) < 1.0, "the officer and student render at matching heights")
	game.set("wallet", 150)
	game.call("_spawn_traffic_row")
	var hazards: Array = game.get("hazards")
	_check(not hazards.is_empty(), "traffic obstacles spawn during the chase")
	_check(hazards.size() <= 3, "traffic rows always leave multiple lanes open")
	var distinct_vehicle_widths: Array[float] = []
	var traffic_speed_scales_valid := true
	for hazard in hazards:
		_check(not game.call("_runner_collision", hazard), "newly spawned traffic is clear of the runner")
		distinct_vehicle_widths.append(float(hazard["width"]))
		traffic_speed_scales_valid = traffic_speed_scales_valid and float(hazard["speed_scale"]) >= 0.94 and float(hazard["speed_scale"]) <= 1.06
	_check(distinct_vehicle_widths.size() == 1 or distinct_vehicle_widths[0] != distinct_vehicle_widths[1], "runner traffic uses varied vehicle lengths")
	_check(traffic_speed_scales_valid, "runner cars spawn with varied vertical speeds")
	var lane_start := float(game.get("player_x"))
	Input.action_press("move_right")
	game.call("_update_chase", 0.1)
	Input.action_release("move_right")
	_check(float(game.get("player_x")) > lane_start, "right input steers the runner toward the next lane")
	var runner_y_start := float(game.get("player_y"))
	Input.action_press("move_up")
	game.call("_update_chase", 0.1)
	Input.action_release("move_up")
	_check(float(game.get("player_y")) < runner_y_start, "W input moves the runner forward in the road")
	Input.action_press("move_down")
	game.call("_update_chase", 0.1)
	Input.action_release("move_down")
	_check(is_equal_approx(float(game.get("player_y")), runner_y_start), "S input moves the runner back to the starting position")
	var saved_difficulty := str(game.get("difficulty"))
	_check(game.get("RUNNER_TRAFFIC_SPEED_MULTIPLIER") == 2.0, "runner traffic uses the requested double-speed multiplier")
	var traffic_displacements := {}
	for option in ["relaxed", "normal", "extreme"]:
		game.set("difficulty", option)
		game.set("runner_elapsed", 0.0)
		var test_hazard: Dictionary = {
			"x": 400.0,
			"y": -200.0,
			"width": 60.0,
			"height": 80.0,
			"speed_scale": 1.0,
		}
		var test_hazards: Array[Dictionary] = [test_hazard]
		game.set("hazards", test_hazards)
		game.set("spawn_timer", 10.0)
		game.set("runner_coin_spawn_timer", 10.0)
		var player_y_before := float(game.get("player_y"))
		if option == "relaxed":
			Input.action_press("move_up")
		game.call("_update_chase", 0.25)
		if option == "relaxed":
			Input.action_release("move_up")
		var moved_hazards: Array = game.get("hazards")
		var moved_hazard: Dictionary = moved_hazards[0]
		var vertical_motion := float(moved_hazard["y"]) + 200.0
		var horizontal_motion := float(moved_hazard["x"]) - 400.0
		var base_speed := float(game.call("_base_speed"))
		var expected_world_speed := minf(base_speed + 0.25 * 0.42, base_speed * 1.65)
		var expected_traffic_motion := expected_world_speed * float(game.call("_difficulty_multiplier")) * 2.0 * 0.25
		_check(is_equal_approx(vertical_motion, expected_traffic_motion), "%s car speed doubles vertically" % option)
		_check(is_zero_approx(horizontal_motion), "%s cars keep their lane while moving vertically" % option)
		traffic_displacements[option] = vertical_motion
		if option == "relaxed":
			_check(float(game.get("player_y")) < player_y_before and vertical_motion > 0.0, "traffic moves down while the runner moves up")
	_check(
		float(traffic_displacements["relaxed"]) < float(traffic_displacements["normal"])
		and float(traffic_displacements["normal"]) < float(traffic_displacements["extreme"]),
		"Relaxed, Normal, and Extreme settings increase car speed in order"
	)
	game.set("difficulty", saved_difficulty)
	game.set("player_y", runner_y_start)
	game.set("hazards", [])
	game.set("difficulty", saved_difficulty)
	var runner_y_moved := runner_y_start - 30.0
	game.set("player_y", runner_y_moved)
	var vertical_test_hazard := {
		"x": float(game.get("player_x")),
		"y": runner_y_moved,
		"width": 60.0,
		"height": 70.0,
	}
	_check(game.call("_runner_collision", vertical_test_hazard), "runner collision bounds follow W/S movement")
	var wallet_before_vertical_coin := int(game.get("wallet"))
	var vertical_test_coins: Array[Dictionary] = [{
		"x": float(game.get("player_x")) + 8.0,
		"y": runner_y_moved + 8.0,
	}]
	game.set("runner_coins", vertical_test_coins)
	game.call("_collect_runner_coins")
	_check(game.get("wallet") == wallet_before_vertical_coin + 2, "runner coin pickup follows W/S movement")
	game.set("wallet", wallet_before_vertical_coin)
	game.set("player_y", runner_y_start)
	game.set("runner_coins", [])

	hazards.clear()
	hazards.append({
		"x": float(game.get("player_x")) - 5.0,
		"y": 390.0,
		"width": 60.0,
		"height": 80.0,
		"jeepney": false,
		"color": Color("#e85d4b"),
	})
	game.set("hazards", hazards)
	game.set("time_left", 90.0)
	_check(game.call("_runner_collision", hazards.back()), "the forced vehicle overlaps the runner before the crash update")
	game.call("_update_chase", 0.01)
	_check(game.get("mode") == "chase" and game.get("overlay") == "", "a paid traffic fine automatically continues the chase without a popup")
	_check(game.get("wallet") == 100 and game.get("attempts_remaining") == 3, "the first crash deducts only the ₱50 fine")
	_check(is_equal_approx(float(game.get("time_left")), 89.99), "the first paid collision preserves the overall countdown")

	game.call("_finish_capture")
	_check(game.get("mode") == "chase" and game.get("overlay") == "" and game.get("wallet") == 50, "a second affordable fine automatically restarts the chase")
	_check(is_equal_approx(float(game.get("time_left")), 89.99), "the second paid collision does not reset the countdown")
	game.call("_finish_capture")
	_check(game.get("mode") == "chase" and game.get("wallet") == 0, "the final affordable fine is paid without a popup")
	_check(is_equal_approx(float(game.get("time_left")), 89.99), "the final paid collision preserves the countdown")
	game.call("_finish_capture")
	_check(game.get("mode") == "result" and game.get("overlay") == "gameover" and game.get("wallet") == 0, "the insufficient-funds popup appears only when the student cannot pay")
	_check(game.get("screen_root").find_child("WASDKeyLayout", true, false) == null, "the runner key pad hides on the result screen")
	game.call("_return_to_crossing")
	_check(game.get("mode") == "crossing" and game.get("wallet") == 0, "the insufficient-funds choice returns to the crossing without resetting allowance")

	game.call("_start_new_cycle")
	_check(game.get("mode") == "crossing" and game.get("wallet") == 150 and game.get("attempts_remaining") == 3, "reset starts a fresh ₱150 three-attempt cycle")
	game.set("wallet", 40)
	game.set("attempts_remaining", 3)
	game.call("_finish_capture")
	_check(game.get("overlay") == "gameover" and game.get("wallet") == 40, "a fine larger than the remaining allowance is not charged")
	game.call("_return_to_crossing")
	_check(game.get("mode") == "crossing" and game.get("wallet") == 40, "returning to the crossing preserves the remaining allowance")
	game.call("_start_new_cycle")
	_check(game.get("mode") == "crossing" and game.get("wallet") == 150 and game.get("attempts_remaining") == 3, "starting a new cycle restores the full allowance and attempts")
	game.set("crossing_cars", [])
	game.set("player_y", 52.0)
	game.call("_update_crossing", 0.0)
	game.call("_start_chase")
	game.set("hazards", [])
	game.set("time_left", 0.005)
	game.call("_update_chase", 0.01)
	_check(game.get("mode") == "celebration" and game.get("overlay") == "", "surviving the two-minute chase starts the school celebration")
	_check(game.get("wallet") == 150 and game.get("attempts_remaining") == 3, "a successful run preserves the full allowance and attempts")
	_check(game.get("has_survived"), "successful escape records level completion")
	_check(int(game.get("best_score")) > 0, "successful runs record the distance best")
	_check(game.get("fastest_arrival_time") > 0.0 and game.get("highest_allowance") >= 150, "successful arrival updates time and allowance records")
	game.call("_process", 4.01)
	_check(game.get("mode") == "home", "a successful chase celebration returns to the main menu")
	game.call("_open_overlay", "achievements")
	var record_labels: Array = game.get("screen_root").find_children("*", "Label", true, false)
	var has_time_record := false
	var has_allowance_record := false
	for record_label in record_labels:
		has_time_record = has_time_record or str((record_label as Label).text).contains("FASTEST ON-TIME")
		has_allowance_record = has_allowance_record or str((record_label as Label).text).contains("HIGHEST ALLOWANCE")
	_check(has_time_record and has_allowance_record, "leaderboard lists fastest on-time and highest allowance records")

	game.call("_start_mini_game")
	_check(game.get("mini_game_mode") and game.get("wallet") == 150, "standalone mini game starts with ₱150")
	game.set("time_left", 0.01)
	game.set("hazards", [])
	game.call("_update_chase", 0.02)
	_check(game.get("mode") == "chase" and game.get("time_left") == 0.01, "mini game has no timer-based ending")
	var mini_coins: Array = game.get("runner_coins")
	mini_coins.append({"x": float(game.get("player_x")) + 8.0, "y": float(game.get("player_y")) + 8.0})
	game.set("runner_coins", mini_coins)
	game.call("_collect_runner_coins")
	_check(game.get("mini_game_money_collected") == 2, "mini game tracks total collected coin money separately")
	_check(game.get("mini_game_highest_money_collected") == 2, "mini-game money record saves independently")
	game.set("distance", 321.0)
	game.set("wallet", 0)
	game.call("_finish_capture")
	_check(game.get("mode") == "result" and game.get("overlay") == "gameover", "mini game ends when the allowance cannot pay a ₱50 fine")
	_check(game.get("mini_game_longest_run") >= 321, "mini game records the longest run separately")
	var mini_game_end_buttons: Array = game.get("screen_root").find_children("*", "Button", true, false)
	var can_run_again := false
	var can_return_home := false
	var has_crossing_choice := false
	for button in mini_game_end_buttons:
		var button_text := (button as Button).text
		can_run_again = can_run_again or button_text == "RUN AGAIN"
		can_return_home = can_return_home or button_text == "MAIN MENU"
		has_crossing_choice = has_crossing_choice or button_text == "RETURN TO CROSSING"
	_check(can_run_again and can_return_home and not has_crossing_choice, "mini-game end popup offers only run again or main menu")
	for button in mini_game_end_buttons:
		if (button as Button).text == "RUN AGAIN":
			(button as Button).emit_signal("pressed")
			break
	_check(game.get("mode") == "chase" and game.get("wallet") == 150 and game.get("mini_game_money_collected") == 0, "run again resets the mini game with fresh money")
	game.call("_go_home")

	game.call("_start_chase")
	game.set("time_left", 0.005)
	game.set("wallet", 150)
	var timeout_hazards: Array[Dictionary] = [{
		"x": float(game.get("player_x")),
		"y": float(game.get("player_y")) - 20.0,
		"width": 60.0,
		"height": 80.0,
		"jeepney": false,
		"color": Color("#e85d4b"),
	}]
	game.set("hazards", timeout_hazards)
	game.call("_update_chase", 0.01)
	_check(game.get("mode") == "result" and game.get("runner_timed_out"), "a final-frame collision after time expires ends in timeout game over")
	_check(game.get("wallet") == 150, "a timeout is not charged as a new traffic fine")
	var timeout_labels: Array = game.get("screen_root").find_children("*", "Label", true, false)
	var timeout_message_visible := false
	for label in timeout_labels:
		timeout_message_visible = timeout_message_visible or (label as Label).text == "TIME RAN OUT!"
	_check(timeout_message_visible, "timeout game over explains that time ran out")

	_finish()


func _has_physical_key(action: String, keycode: int) -> bool:
	var expected := InputEventKey.new()
	expected.physical_keycode = keycode
	return InputMap.action_has_event(action, expected)


func _check(condition: bool, description: String) -> void:
	if condition:
		print("PASS  ", description)
	else:
		failures.append(description)
		push_error("FAIL  " + description)


func _finish() -> void:
	if failures.is_empty():
		print("ROAD RUSH SMOKE TEST PASSED")
		quit(0)
	else:
		push_error("ROAD RUSH SMOKE TEST FAILED: %d check(s)" % failures.size())
		quit(1)
