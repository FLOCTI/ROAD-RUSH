# ROAD RUSH

A keyboard-playable Godot 4 arcade game about a university student crossing a
fictionalized Cebu City street, then outrunning traffic and a pursuing officer
in a scrolling 2D lane runner. The first level is inspired by Sangtianko Street.

## Requirements

- Godot Engine 4.2 or newer (the project was checked with Godot 4.7.2).
- Windows, macOS, or Linux desktop.
- No network access, external packages, Kotlin, or Gradle are required.

The game is a native Godot desktop project. An Android export is not included;
building one requires the matching Godot export templates and Android SDK.

## Run the game

1. Unzip the project.
2. Open `ROAD_RUSH_GODOT/project.godot` in Godot 4.
3. Wait for Godot to import the two character images.
4. Press **F6** to run the game or **F5** to run the main scene.

You can also start it from a terminal:

```text
godot --path ROAD_RUSH_GODOT
```

### Run from VS Code

Open either the `ROAD_RUSH_GODOT` folder or the repository folder in VS Code.
Install the recommended **Godot Tools** extension if prompted, then press
**F5** and choose **Launch ROAD RUSH**. The launch configuration runs the
project's main scene with the GDScript debugger.

The workspace configuration points to the Godot 4.7.2 executable installed on
this Windows machine. If Godot is installed elsewhere, update
`godotTools.editorPath.godot4` in `.vscode/settings.json` and `editor_path` in
`.vscode/launch.json` to its executable path.

## Controls

| Action | Controls |
| --- | --- |
| Move during the crossing | W / A / S / D or arrow keys |
| Steer during the traffic chase | A / D or left / right arrows |
| Pause or resume | Esc or the on-screen Pause button |
| Start from the title screen | Enter / Space or Start Game |

The mouse can be used for all menus and on-screen buttons. Select **HOW TO
PLAY** on the title screen to open the in-game instructions.

## Gameplay

- A short opening animation fades into Cebu, introduces the enlarged pixel-art
  student and officer fleeing a towering jeepney. The jeepney follows close
  behind with bouncing suspension, spinning pixel wheels, and exhaust puffs to
  emphasize the chase. The intro reveals the title with a bold layered pixel
  wordmark, then fades into the main menu. The selected student sprite uses
  nearest-neighbor rendering.
- Begin each ROAD RUSH cycle with **₱150** and **three attempts**. Allowance
  remains visible during both the main game and the Mini Game.
- Cross the traffic-filled road between Cebu-inspired cars and jeepneys. A
  large signal sits on the sidewalk beside a warning placard. Its cycle has
  seven seconds of green, one second of yellow, and five seconds of red. Only
  crossing on red while staying inside the worn white lane counts as a pass;
  touching the road outside the lane or being on the road during green or
  yellow is jaywalking. A jaywalking student is caught in a three-second
  animation, then transitions directly into the traffic chase without a popup
  or menu choice.
- The unmaintained crosswalk has chipped, faded paint. Collectible coins are
  scattered across the road and add **₱5** each, including tempting coins
  outside the marked route. Traffic collisions return the student to the near
  sidewalk without using an attempt.
- Passing the crossing on red within the white lane, or surviving the complete
  traffic chase, plays a detailed four-second arrival celebration at the
  University of the Visayas. The student runs into the distinct UV campus
  building before the game returns to the main menu. Only lawful crossings
  qualify for the on-time arrival record.
- Crossing collisions use the student's lower body rather than the full tall
  sprite, so a car touching only the character's head does not reset the
  crossing.
- The title menu also offers a standalone **Runner Challenge**. Its separate
  longest-run and money-collected leaderboard appears in **Achievements**.
- Dodge cars and Cebu-inspired jeepneys on a scrolling five-lane street. Each
  traffic row leaves several readable gaps, and traffic becomes faster as the
  two-minute chase progresses. Collect the moving road coins for **₱2** each;
  they increase the same allowance earned during the crossing.
- Steer left and right to avoid traffic and collect coins while the
  green-uniformed officer pursues the student from behind on the same path at
  a matching sprite height. Survive the two-minute rush to reach campus.
- Each capture automatically deducts **₱50** and restarts the chase when the
  allowance can cover the fine; no popup interrupts a paid retry. If the
  allowance is below **₱50**, a prompt returns the student to the crossing
  without resetting the remaining money, so more coins can be collected.
- In **Mini Game**, the runner has no timer and continues through paid crashes
  until the remaining allowance cannot cover another **₱50** fine. The end
  popup offers **Run Again** with a fresh ₱150 or **Main Menu**. Its leaderboard
  tracks the longest single run and the most total coin money collected,
  independently of the main game's records.
- Completing the two-minute run finishes the level without a fine or bonus,
  preserving the remaining allowance and attempts.
- Choose Relaxed, Normal, or Monday Rush difficulty.
- Select the girl or boy student, create up to three local player profiles,
  and check achievements, fastest on-time arrival, highest allowance, and best
  distance. Record holders are saved locally with the other game records.
- Options, profiles, and records are saved locally with Godot's `ConfigFile`
  under `user://road_rush_save.cfg`.

## Project structure

```text
ROAD_RUSH_GODOT/
├── assets/
│   ├── student_boy.png
│   └── student_girl.png
├── scenes/
│   └── main.tscn
├── scripts/
│   └── main.gd
├── tests/
│   └── smoke_test.gd
├── project.godot
└── README.md
```

The scene uses a GDScript controller for movement, crossing traffic, the
scrolling lane runner, officer pursuit, allowance, save data, and menu flow.
The Cebu street, buildings, road, and vehicles are drawn at runtime with crisp,
low-resolution shapes. The student uses the supplied pixel-art sprite, and the
traffic officer is drawn in a matching palette.
Menus, pause, settings, tutorial, allowance, and result dialogs use compact,
scrollable pixel-art panels with square borders and bold arcade buttons. The
game-over screen highlights distance and allowance in stat cards. The supplied
student portraits are used in character selection.

The project bundles the **Pixelify Sans** variable display font under the SIL
Open Font License 1.1. Its heavier pixel lettering is used throughout the
interface and in-game text. The font license is included at
`assets/fonts/OFL.txt`.

## Validate

From the project directory with Godot on `PATH`, run the headless gameplay
smoke test:

```text
godot --headless --path . --user-data-dir .godot/test_userdata --script res://tests/smoke_test.gd
```

The test exercises startup and input mappings, crossing collisions and
handoff, fair traffic spawning, ₱2 runner coin pickups, automatic affordable
fine retries, mini-game time-free play and separate leaderboard records,
insufficient-funds handling, and survival completion with preserved
allowance.
